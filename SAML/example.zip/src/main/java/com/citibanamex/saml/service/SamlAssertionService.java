package com.citibanamex.saml.service;

import java.security.interfaces.RSAPrivateKey;

import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Response;

public interface SamlAssertionService {

	RSAPrivateKey getPrivateKeyFromJKS(String jksFilePath, String keyStorePassword, String jksCertificateAlias) throws Exception;
	Response getDecodedResponseFromSamlAssertion(String payload) throws Exception;
	String getDecryptedSamlResponseXML(RSAPrivateKey privateKey, Response response) throws Exception;
	Assertion getDecryptedSamlResponse(RSAPrivateKey privateKey, Response response) throws Exception;
}