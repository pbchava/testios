package com.citibanamex.saml.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.util.Base64;
import java.util.Objects;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.io.IOUtils;

public final class CryptoUtil {

	private CryptoUtil() {
	}

	public static byte[] extractBlockBytes(InputStream data, int length) throws Exception {

		if (Objects.isNull(data) || length < CipherConstants.ZERO) {
			return new byte[CipherConstants.ZERO];
		}

		int read = CipherConstants.ZERO;
		try {
			byte[] vector = new byte[length];

			while (read < length) {
				read += data.read(vector, read, CipherConstants.ONE);
			}

			return vector;
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage());
		}
	}

	public static SecretKey decryptKey(final byte[] dataKey, final RSAPrivateKey privateKey)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
		final byte[] encryptedKey = Base64.getDecoder().decode(dataKey);
		final Cipher rsaOaepPadding = Cipher.getInstance(CipherConstants.RSA_OAEP_PADDING_ALGORITHM);

		rsaOaepPadding.init(Cipher.UNWRAP_MODE, privateKey);
		return (SecretKey) rsaOaepPadding.unwrap(encryptedKey, CipherConstants.AES, Cipher.SECRET_KEY);
	}

	public static byte[] decryptData(final byte[] encryptedData, final SecretKey secretKey) throws Exception {
		final InputStream encryptedStream = new ByteArrayInputStream(encryptedData);
		final byte[] iv = extractBlockBytes(encryptedStream, CipherConstants.IV_INIT_VECTOR_SIZE);

		final Cipher cipherDec = Cipher.getInstance(CipherConstants.AES_CBC_ALGORITHM);
		cipherDec.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));

		new SecureRandom().nextBytes(iv);
		return IOUtils.toByteArray(new CipherInputStream(encryptedStream, cipherDec));
	}
}