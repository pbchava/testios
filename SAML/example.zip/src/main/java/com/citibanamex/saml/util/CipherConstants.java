package com.citibanamex.saml.util;

public class CipherConstants {

	/** AES IV initialization block size. */
	public static final int IV_INIT_VECTOR_SIZE = 16;
	/** AES algorithm. */
	public static final String AES = "AES";
	/** RSA encrypt/decrypt algorithm for SAML response encrypted key. */
	public static final String RSA_OAEP_PADDING_ALGORITHM = "RSA/ECB/OAEPwithSHA1andMGF1Padding";
	/** AES CBC operation mode algorithm. */
	public static final String AES_CBC_ALGORITHM = "AES/CBC/NoPadding";
	/** General format error. */
	public static final String GENERAL_ERROR = "{}. Caused by: {}";
	/** Zero integer value. */
	public static final int ZERO = 0;
	/** Zero integer value. */
	public static final int ONE = 1;
	/** End xml tag assertion. */
	public static final String END_XML_ASSERTION = "</saml:Assertion>";
	/** Unable to get key decrypted message. */
	public static final String ERROR_DECRYPT_KEY_MESSAGE = "Unable to get key decrypted {} ";
	/** Error decryption process to get cipher data decrypted. */
	public static final String ERROR_DECRYPT_CIPHERDATA_MESSAGE = "Error at decryption ciphered data process: unable to decrypt data [{}] ";
	/** Error assertion process unable to parse document fragment message. */
	public static final String ERROR_ASSERTION_PROCESS_UNABLE_PARSING_DOC = "Error at assertion process: unable to parse document fragment [{}]";
	/** Unable to parse document fragment message. */
	public static final String ERROR_UNABLE_PARSE_DOC = "Unable parse document {} ";
	/** Error bad parsing stream message. */
	public static final String ERROR_BAD_PARSING_STREAM_DATA_MESSAGE = "Error parsing decrypted input stream: {}";
	/** Error basic parser pool parsing input stream message. */
	public static final String ERROR_BASICPARSERPOOL_INPUT_STREAM_MESSAGE = "Error parsing input stream.";
	/** Document fragment is null message. */
	public static final String ERROR_DOCUMENT_FRAGMT_OBJECT_NULL_MESSAGE = "Document fragment object is null.";
	/** Error XMLObject list more than required message. */
	public static final String ERROR_DECRYPT_OBJ_MORE_THAN_REQUIRED = "The decrypted data contained more than one top-level XMLObject child.";
	/** Error create document message. */
	public static final String ERROR_CREATE_NEW_DOC = "Error creating new DOM Document";
	/** Error during process unable to locate unmarshaller message. */
	public static final String ERROR_PROCESS_UNABLE_LOCATING_UNMARSHALLER_MESSAGE = "Error at unable to locate unmarshaller for {}";
	/** Error unable to locate unmarshaller message. */
	public static final String ERROR_UNABLE_LOCATE_UNMARSHALLER = "Unable to locate unmarshaller for: ";
	/** Error exception unmarshalling message. */
	public static final String ERROR_SOME_EXCEPTION_UNMARSHALLING_MESSAGE = "There was an error during unmarshalling of the decrypted element";
	/** Error exception message during unmarshalling. */
	public static final String ERROR_UNMARSHALL_EXCEPTION_MESSAGE = "Unmarshalling error during decryption";

	/** Private Constructor CipherConstants. */
	private CipherConstants() {
	}
}