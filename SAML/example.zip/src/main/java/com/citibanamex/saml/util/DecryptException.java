package com.citibanamex.saml.util;

public class DecryptException extends RuntimeException {

	private static final long serialVersionUID = -6001897084398693226L;

	public DecryptException(String message) {
		super(message);
	}

	public DecryptException(String message, Throwable cause) {
		super(message, cause);
	}
}