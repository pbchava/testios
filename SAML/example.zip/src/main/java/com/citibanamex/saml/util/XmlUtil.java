package com.citibanamex.saml.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlUtil {

	private static final String ASSERTION = "saml:Assertion";
	private static final String SIGNATURE = "ds:Signature";
	public static final String YES = "yes";

	public static final int ZERO = 0;
	public static final String XM_DISALLOW_DOCTYPE_DECL = "http://apache.org/xml/features/disallow-doctype-decl";
	public static final String XML_EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
	public static final String XML_EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";

	private XmlUtil() {
	}

	public static InputStream fixXml(InputStream inputStreamBadXml) {
		try {

			Element elementXml = getElementFromInputStream(inputStreamBadXml);
			NodeList xmlDec = null;
			Node nodeSign = null;
			if (elementXml != null) {
				xmlDec = elementXml.getChildNodes();
				for (int i = 0; i < xmlDec.getLength(); i++) {
					Node node = xmlDec.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE && SIGNATURE.equals(node.getNodeName())) {
						nodeSign = node;
						elementXml.removeChild(node); // ESTA PARTE REMUEVE EL NODE SIGNATURE DEL XML ORIGINAL
					}
				}
			}

			String xmlEncryptedFinal = null;

			if (nodeSign != null) {
				getAssertionsFromXml(xmlDec, nodeSign, elementXml);

				xmlEncryptedFinal = formatXml(elementXml);
			}
			if (xmlEncryptedFinal == null) {
				throw new IOException();
			}
			return new ByteArrayInputStream(xmlEncryptedFinal.getBytes(StandardCharsets.UTF_8));
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static Element getElementFromInputStream(InputStream inputStream) {
		Document doc = null;
		try {
			String xmlBad = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

			byte[] bytesRes = Base64.decodeBase64(xmlBad.getBytes(StandardCharsets.UTF_8));
			String response = new String(bytesRes, StandardCharsets.UTF_8);

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			dbf.setFeature(XM_DISALLOW_DOCTYPE_DECL, true);
			dbf.setFeature(XML_EXTERNAL_GENERAL_ENTITIES, false);
			dbf.setFeature(XML_EXTERNAL_PARAMETER_ENTITIES, false);

			DocumentBuilder db = dbf.newDocumentBuilder();
			ByteArrayInputStream bis = new ByteArrayInputStream(response.getBytes(StandardCharsets.UTF_8));
			doc = db.parse(bis);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return doc == null ? null : doc.getDocumentElement();
	}

	private static String formatXml(Element elementXml) {
		String xmlStringFinal;
		String xmlEncryptedFinal = null;
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, StringUtils.EMPTY);
		transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, StringUtils.EMPTY);

		try {
			Transformer trans = transformerFactory.newTransformer();
			trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, YES);

			StringWriter writer = new StringWriter();
			trans.transform(new DOMSource(elementXml), new StreamResult(writer));

			xmlStringFinal = writer.toString();
			byte[] bytes = Base64.encodeBase64(xmlStringFinal.getBytes(StandardCharsets.UTF_8));
			xmlEncryptedFinal = new String(bytes, StandardCharsets.UTF_8);
		} catch (TransformerException ex) {
			System.out.println(ex.getMessage());
		}
		return xmlEncryptedFinal;
	}

	private static void getAssertionsFromXml(NodeList xmlDec, Node nodeSign, Element elementXml) {
		for (int i = ZERO; i < xmlDec.getLength(); i++) {
			Node node = xmlDec.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE && ASSERTION.equals(node.getNodeName())) {
				elementXml.getElementsByTagName(ASSERTION).item(ZERO).appendChild(nodeSign);
			}
		}
	}
}
