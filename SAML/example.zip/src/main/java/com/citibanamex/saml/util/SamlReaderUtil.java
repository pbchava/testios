package com.citibanamex.saml.util;

import java.io.InputStream;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.opensaml.DefaultBootstrap;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class SamlReaderUtil {
	private static BasicParserPool basicParserPool;
	private static SamlReaderUtil samlReaderUtil;

	public static SamlReaderUtil getInstance() {
		if (samlReaderUtil == null) {
			samlReaderUtil = new SamlReaderUtil();
		}
		return samlReaderUtil;
	}

	private SamlReaderUtil() {
		try {
			DefaultBootstrap.bootstrap();
			basicParserPool = new BasicParserPool();
			basicParserPool.setNamespaceAware(true);
		} catch (Exception ex) {
			throw new IllegalStateException(ex.getMessage());
		}
	}

	public XMLObject fromElement(Element element) throws UnmarshallingException {
		return org.opensaml.xml.Configuration.getUnmarshallerFactory().getUnmarshaller(element).unmarshall(element);
	}

	public Element getElement(Reader readerXml) throws XMLParserException {
		return basicParserPool.parse(readerXml).getDocumentElement();
	}

	public DocumentFragment parseInputStream(InputStream input, Document owningDocument) throws DecryptionException {

		Document newDocument;
		try {
			newDocument = basicParserPool.parse(input);
		} catch (Exception ex) {
			throw new DecryptionException(CipherConstants.ERROR_BASICPARSERPOOL_INPUT_STREAM_MESSAGE, ex);
		}

		Element element = newDocument.getDocumentElement();
		owningDocument.adoptNode(element);

		DocumentFragment container = owningDocument.createDocumentFragment();
		container.appendChild(element);

		return container;
	}

	public List<XMLObject> docFragmentToListXmlObject(DocumentFragment docFragment, boolean rootInNewDocument)
			throws DecryptException {

		Node node;
		Element element;
		XMLObject xmlObject;
		List<XMLObject> xmlObjects = new LinkedList<XMLObject>();

		NodeList children = docFragment.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			node = children.item(i);

			element = (Element) node;
			if (rootInNewDocument) {
				Document newDoc;
				try {
					newDoc = basicParserPool.newDocument();
				} catch (XMLParserException ex) {
					throw new DecryptException(CipherConstants.ERROR_CREATE_NEW_DOC, ex);
				}
				newDoc.adoptNode(element);
				newDoc.appendChild(element);
			}

			try {
				final Element nodeElem = element;
				Unmarshaller unmarshaller = org.opensaml.xml.Configuration.getUnmarshallerFactory()
						.getUnmarshaller(nodeElem);
				if (Objects.isNull(unmarshaller)) {
					unmarshaller = Optional
							.ofNullable(org.opensaml.xml.Configuration.getUnmarshallerFactory()
									.getUnmarshaller(org.opensaml.xml.Configuration.getDefaultProviderQName()))
							.orElseThrow(() -> {
								return new DecryptException(
										CipherConstants.ERROR_UNABLE_LOCATE_UNMARSHALLER + nodeElem.getNodeName());
							});
				}
				xmlObject = unmarshaller.unmarshall(element);
			} catch (UnmarshallingException ex) {
				throw new DecryptException(CipherConstants.ERROR_UNMARSHALL_EXCEPTION_MESSAGE, ex);
			}

			xmlObjects.add(xmlObject);
		}

		return xmlObjects;
	}

	public XMLObject parseDocFragment(DocumentFragment docFragment, boolean rootInNewDocument) throws DecryptException {
		if (Objects.isNull(docFragment)) {
			throw new DecryptException(CipherConstants.ERROR_DOCUMENT_FRAGMT_OBJECT_NULL_MESSAGE);
		}

		List<XMLObject> xmlObjects = docFragmentToListXmlObject(docFragment, rootInNewDocument);

		return xmlObjects.get(0);
	}
}
