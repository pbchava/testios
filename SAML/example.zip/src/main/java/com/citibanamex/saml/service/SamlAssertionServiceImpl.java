package com.citibanamex.saml.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPrivateKey;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.EncryptedAssertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.encryption.CipherData;
import org.opensaml.xml.encryption.CipherValue;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.encryption.EncryptedData;
import org.opensaml.xml.encryption.EncryptedKey;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.signature.KeyInfo;
import org.w3c.dom.DocumentFragment;

import com.citibanamex.saml.util.CipherConstants;
import com.citibanamex.saml.util.CryptoUtil;
import com.citibanamex.saml.util.SamlReaderUtil;

public class SamlAssertionServiceImpl implements SamlAssertionService{

	private final static String JSK = "JKS";
	private final static SamlReaderUtil samlReaderUtil = SamlReaderUtil.getInstance();
	
	public RSAPrivateKey getPrivateKeyFromJKS(String jksFilePath, String keyStorePassword, String jksCertificateAlias)
			throws KeyStoreException, UnrecoverableEntryException, NoSuchAlgorithmException, IOException,
			CertificateException {
		KeyStore keyStore = KeyStore.getInstance(JSK);

		InputStream stream = new FileInputStream(new File(jksFilePath));
		keyStore.load(stream, keyStorePassword.toCharArray());

		KeyStore.PrivateKeyEntry entry = (KeyStore.PrivateKeyEntry) 
				keyStore.getEntry(
						jksCertificateAlias,
						new KeyStore.PasswordProtection(keyStorePassword.toCharArray())
				);

		return (RSAPrivateKey) entry.getPrivateKey();
	}

	public Response getDecodedResponseFromSamlAssertion(String payload) throws XMLParserException, UnmarshallingException {
		byte[] xml = Base64.decodeBase64(payload);
		Reader readerXml = new InputStreamReader(new ByteArrayInputStream(xml), StandardCharsets.UTF_8);

		return (Response) samlReaderUtil.fromElement(
				samlReaderUtil.getElement(readerXml));
	}

	public String getDecryptedSamlResponseXML(RSAPrivateKey privateKey, Response response) throws Exception {
		SecretKey secretKey = SamlAssertionHelper.getDecryptedAESKey(privateKey, response);
		byte[] assertionBytes = SamlAssertionHelper.decryptCipheredData(secretKey, response);
		
		return SamlAssertionHelper.getSamlXmlData(assertionBytes); 
	}
	
	public Assertion getDecryptedSamlResponse(RSAPrivateKey privateKey, Response response) throws Exception {
		String xml = getDecryptedSamlResponseXML(privateKey, response);
		
		return SamlAssertionHelper.getAssertion(xml, response);
	}

	private static class SamlAssertionHelper {
		
		public static String getSamlXmlData(byte[] assertionBytes) {
			String xml = new String(assertionBytes, StandardCharsets.UTF_8);

			return xml.substring(CipherConstants.ZERO,
					xml.lastIndexOf(CipherConstants.END_XML_ASSERTION) + CipherConstants.END_XML_ASSERTION.length()
					);
		}

		public static SecretKey getDecryptedAESKey(RSAPrivateKey privateKey, Response response) throws InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
			return CryptoUtil.decryptKey(
					SamlAssertionHelper.getEncryptedKey(response).getBytes(StandardCharsets.UTF_8)
					, privateKey);
		}

		public static byte[] decryptCipheredData(SecretKey secretKey, Response response) throws Exception {
			return 	CryptoUtil.decryptData(
					Base64.decodeBase64(
							SamlAssertionHelper.getCipheredData(response)), 
					secretKey);
		}
		
		public static Assertion getAssertion(String xml, Response response) throws DecryptionException {
			DocumentFragment docFragment = samlReaderUtil.parseInputStream(
					new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)),
					SamlAssertionHelper.getEncryptedData(response).getDOM().getOwnerDocument());

			return (Assertion) samlReaderUtil.parseDocFragment(docFragment, Boolean.FALSE);
		}

		public static String getEncryptedKey(Response response) {
			EncryptedAssertion encryptedAssertion = response.getEncryptedAssertions().get(0);
			EncryptedData encryptedData = encryptedAssertion.getEncryptedData();
			KeyInfo keyInfo = encryptedData.getKeyInfo();
			EncryptedKey encryptedKey = keyInfo.getEncryptedKeys().get(0);
			CipherData cipheredData = encryptedKey.getCipherData();
			CipherValue cipherValue = cipheredData.getCipherValue();
			return cipherValue.getValue();
		}

		public static EncryptedData getEncryptedData(Response response) {
			return response.getEncryptedAssertions().get(0).getEncryptedData();
		}

		public static String getCipheredData(Response response) {
			EncryptedAssertion encryptedAssertion = response.getEncryptedAssertions().get(0);
			EncryptedData encryptedData = encryptedAssertion.getEncryptedData();
			CipherData cipheredData = encryptedData.getCipherData();
			CipherValue cipherValue = cipheredData.getCipherValue();
			return cipherValue.getValue();
		}
	}
}