# healthcheck-war

Proyecto Maven que genera un WAR (`healthcheck.war`) con un servicio REST
de *liveness check* para WildFly 27+ (Jakarta EE 10).

## Endpoint

```
GET /healthcheck/api/health
```

- **200 OK** con cuerpo `{"status":"UP","timestamp":"..."}` si el servidor
  respondio la peticion (es decir, WildFly esta operando).
- Si WildFly esta caido, no habra respuesta HTTP en absoluto (timeout /
  connection refused), lo cual es la senal de "no operando correctamente"
  para quien lo consuma (monitoreo, load balancer, pipeline CI/CD, etc.).

## Compilar

```bash
mvn clean package
```

Esto genera `target/healthcheck.war`.

> Si tu WildFly no es exactamente Jakarta EE 10, ajusta la version de
> `jakarta.jakartaee-web-api` en el `pom.xml` a la que corresponda a tu
> version de WildFly.

## Desplegar

Copia el WAR generado a la carpeta de despliegues de WildFly:

```bash
cp target/healthcheck.war $WILDFLY_HOME/standalone/deployments/
```

O usa la consola de administracion / `jboss-cli.sh`:

```bash
$WILDFLY_HOME/bin/jboss-cli.sh --connect \
  --command="deploy target/healthcheck.war --force"
```

## Probar

```bash
curl -i http://localhost:8080/healthcheck/api/health
```

Respuesta esperada:

```
HTTP/1.1 200 OK
Content-Type: application/json
...

{"status":"UP","timestamp":"2026-09-03T12:00:00.000Z"}
```

## Uso tipico

- Configurar un `HTTPHealthCheck` en tu load balancer / API Gateway
  apuntando a `GET /healthcheck/api/health`, esperando codigo `200`.
- Usarlo como *readiness probe* en Kubernetes/OpenShift si WildFly
  corre en un contenedor.
- Integrarlo en un pipeline de CI/CD (GitHub Actions / Bitbucket) como
  paso de verificacion post-despliegue con `curl -f`.

## Estructura del proyecto

```
healthcheck-war/
├── pom.xml
├── README.md
└── src/main
    ├── java/mx/chava/healthcheck/rest/
    │   ├── JaxRsActivator.java      # activa JAX-RS bajo /api
    │   └── HealthCheckResource.java # GET /api/health
    └── webapp/WEB-INF/
        └── jboss-web.xml            # fija el context-root en /healthcheck
```
