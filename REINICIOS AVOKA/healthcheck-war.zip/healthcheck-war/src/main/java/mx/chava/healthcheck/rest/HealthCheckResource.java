package mx.chava.healthcheck.rest;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.time.Instant;

/**
 * Liveness check simple.
 *
 * El propio hecho de que este recurso responda ya implica que:
 *   - WildFly esta arriba y aceptando conexiones.
 *   - El contenedor web (Undertow) esta funcionando.
 *   - Esta WAR quedo correctamente desplegada.
 *
 * Si WildFly esta caido, el cliente vera timeout / connection refused
 * en lugar de una respuesta HTTP, lo cual tambien es una senal valida
 * de "no operando correctamente" para quien consuma este endpoint
 * (monitoreo, balanceador, script de CI/CD, etc.).
 */
@Path("/health")
public class HealthCheckResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response healthCheck() {
        String body = String.format(
                "{\"status\":\"UP\",\"timestamp\":\"%s\"}",
                Instant.now().toString()
        );
        // HTTP 200 = servidor operando correctamente.
        return Response.status(Response.Status.OK)
                .entity(body)
                .build();
    }
}
