package mx.chava.healthcheck.monitor;

import org.springframework.stereotype.Component;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.OperatingSystemMXBean;
import java.lang.management.ThreadMXBean;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class ResourceMonitor {

    private static final Logger LOGGER = Logger.getLogger(ResourceMonitor.class.getName());

    public ResourceMetricsSample captureSample() {
        OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
        ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();

        long heapUsed = memoryBean.getHeapMemoryUsage().getUsed();
        long heapMax = memoryBean.getHeapMemoryUsage().getMax();
        double heapUsagePct = heapMax > 0 ? ((double) heapUsed / heapMax) * 100.0 : 0.0;

        double systemCpuLoad = getReflectionMetric(osBean, "getSystemCpuLoad");
        double processCpuLoad = getReflectionMetric(osBean, "getProcessCpuLoad");

        return new ResourceMetricsSample(
            System.currentTimeMillis(),
            heapUsed,
            heapMax,
            heapUsagePct,
            systemCpuLoad,
            processCpuLoad,
            threadBean.getThreadCount(),
            osBean.getSystemLoadAverage()
        );
    }

    private double getReflectionMetric(OperatingSystemMXBean osBean, String methodName) {
        try {
            Method method = osBean.getClass().getMethod(methodName);
            method.setAccessible(true);
            Object value = method.invoke(osBean);
            if (value instanceof Number) {
                return ((Number) value).doubleValue();
            }
        } catch (Exception e) {
            LOGGER.log(Level.FINE, "No se pudo obtener la métrica " + methodName + " mediante reflexión", e);
        }
        return -1.0;
    }
}
