package mx.chava.healthcheck.controller;

import mx.chava.healthcheck.monitor.ResourceMetricsSample;
import mx.chava.healthcheck.monitor.ResourceMonitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class HealthCheckController {

    private final ResourceMonitor resourceMonitor;

    @Autowired
    public HealthCheckController(ResourceMonitor resourceMonitor) {
        this.resourceMonitor = resourceMonitor;
    }

    @GetMapping("/health")
    public ResponseEntity<ResourceMetricsSample> checkHealth() {
        ResourceMetricsSample sample = resourceMonitor.captureSample();
        return ResponseEntity.ok(sample);
    }

    @GetMapping("/metrics")
    public ResponseEntity<ResourceMetricsSample> getMetrics() {
        ResourceMetricsSample sample = resourceMonitor.captureSample();
        return ResponseEntity.ok(sample);
    }
}
