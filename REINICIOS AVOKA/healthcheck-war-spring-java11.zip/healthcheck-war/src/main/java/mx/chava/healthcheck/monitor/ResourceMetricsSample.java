package mx.chava.healthcheck.monitor;

import java.io.Serializable;

public class ResourceMetricsSample implements Serializable {
    private static final long serialVersionUID = 1L;

    private long timestamp;
    private long heapUsed;
    private long heapMax;
    private double heapUsagePct;
    private double systemCpuLoad;
    private double processCpuLoad;
    private int threadCount;
    private double systemLoadAverage;

    public ResourceMetricsSample() {
    }

    public ResourceMetricsSample(long timestamp, long heapUsed, long heapMax, double heapUsagePct,
                                double systemCpuLoad, double processCpuLoad, int threadCount, double systemLoadAverage) {
        this.timestamp = timestamp;
        this.heapUsed = heapUsed;
        this.heapMax = heapMax;
        this.heapUsagePct = heapUsagePct;
        this.systemCpuLoad = systemCpuLoad;
        this.processCpuLoad = processCpuLoad;
        this.threadCount = threadCount;
        this.systemLoadAverage = systemLoadAverage;
    }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public long getHeapUsed() { return heapUsed; }
    public void setHeapUsed(long heapUsed) { this.heapUsed = heapUsed; }

    public long getHeapMax() { return heapMax; }
    public void setHeapMax(long heapMax) { this.heapMax = heapMax; }

    public double getHeapUsagePct() { return heapUsagePct; }
    public void setHeapUsagePct(double heapUsagePct) { this.heapUsagePct = heapUsagePct; }

    public double getSystemCpuLoad() { return systemCpuLoad; }
    public void setSystemCpuLoad(double systemCpuLoad) { this.systemCpuLoad = systemCpuLoad; }

    public double getProcessCpuLoad() { return processCpuLoad; }
    public void setProcessCpuLoad(double processCpuLoad) { this.processCpuLoad = processCpuLoad; }

    public int getThreadCount() { return threadCount; }
    public void setThreadCount(int threadCount) { this.threadCount = threadCount; }

    public double getSystemLoadAverage() { return systemLoadAverage; }
    public void setSystemLoadAverage(double systemLoadAverage) { this.systemLoadAverage = systemLoadAverage; }
}
