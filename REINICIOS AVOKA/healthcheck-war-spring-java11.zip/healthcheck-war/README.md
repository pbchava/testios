# HealthCheck WAR (Spring Framework 5.3.x)

Proyecto migrado a **Spring Web / MVC (versión 5.3.39)** para máxima compatibilidad con **Java 11 y Java 21** en WildFly.

## Ajustes realizados
1. **Compatibilidad Java 11:** Uso de Spring Framework 5.3.39 y `javax.servlet-api:4.0.1`.
2. **Spring Web:** Uso de `@RestController` y `@GetMapping`.
3. **Métricas JPMS:** Monitoreo mediante reflexión segura para evitar conflictos en Java 11 / 21.
