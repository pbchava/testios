package mx.chava.healthcheck.monitor;

import javax.inject.Inject;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Engancha el ciclo de vida del {@link ResourceMonitor} al ciclo de vida
 * del propio WAR:
 *
 * <ul>
 *   <li>{@code contextInitialized}: se dispara cuando WildFly termina de
 *       desplegar la aplicacion -> arranca el muestreo en background.</li>
 *   <li>{@code contextDestroyed}: se dispara al des-desplegar o al
 *       apagar WildFly -> detiene el scheduler limpiamente.</li>
 * </ul>
 */
@WebListener
public class HealthCheckApplicationLifecycle implements ServletContextListener {

    @Inject
    ResourceMonitor resourceMonitor;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        resourceMonitor.start();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        resourceMonitor.stop();
    }
}
