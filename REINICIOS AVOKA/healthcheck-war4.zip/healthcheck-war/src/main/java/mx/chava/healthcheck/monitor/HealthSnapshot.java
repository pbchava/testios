package mx.chava.healthcheck.monitor;

/**
 * Snapshot inmutable y precalculado del estado de salud.
 *
 * Clase inmutable clasica (en vez de record) para mantener
 * compatibilidad con Java 11 (record requiere Java 16+).
 *
 * Este objeto es lo UNICO que el endpoint REST lee para responder: no
 * hace ningun calculo en el momento de la peticion, por lo que la
 * respuesta HTTP es practicamente instantanea (lectura de una
 * referencia en memoria), sin importar cuantas muestras historicas
 * existan.
 */
public final class HealthSnapshot {

    private final boolean healthy;
    private final double cpuPercent;
    private final double memoryPercent;
    private final boolean cpuDegraded;
    private final boolean memoryDegraded;
    private final long cpuBreachDurationSeconds;
    private final long memoryBreachDurationSeconds;
    private final long timestampMillis;

    public HealthSnapshot(
            boolean healthy,
            double cpuPercent,
            double memoryPercent,
            boolean cpuDegraded,
            boolean memoryDegraded,
            long cpuBreachDurationSeconds,
            long memoryBreachDurationSeconds,
            long timestampMillis
    ) {
        this.healthy = healthy;
        this.cpuPercent = cpuPercent;
        this.memoryPercent = memoryPercent;
        this.cpuDegraded = cpuDegraded;
        this.memoryDegraded = memoryDegraded;
        this.cpuBreachDurationSeconds = cpuBreachDurationSeconds;
        this.memoryBreachDurationSeconds = memoryBreachDurationSeconds;
        this.timestampMillis = timestampMillis;
    }

    /**
     * Snapshot inicial optimista, usado antes de que el monitor tome su
     * primera muestra real (deployment recien iniciado).
     */
    public static HealthSnapshot initialUp() {
        return new HealthSnapshot(true, -1, -1, false, false, 0, 0, System.currentTimeMillis());
    }

    public boolean healthy() {
        return healthy;
    }

    public double cpuPercent() {
        return cpuPercent;
    }

    public double memoryPercent() {
        return memoryPercent;
    }

    public boolean cpuDegraded() {
        return cpuDegraded;
    }

    public boolean memoryDegraded() {
        return memoryDegraded;
    }

    public long cpuBreachDurationSeconds() {
        return cpuBreachDurationSeconds;
    }

    public long memoryBreachDurationSeconds() {
        return memoryBreachDurationSeconds;
    }

    public long timestampMillis() {
        return timestampMillis;
    }
}
