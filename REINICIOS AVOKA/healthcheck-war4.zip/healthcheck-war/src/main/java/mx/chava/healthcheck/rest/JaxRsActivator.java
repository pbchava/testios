package mx.chava.healthcheck.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Activa JAX-RS (RESTEasy, incluido en WildFly) sin necesidad de web.xml.
 * Todos los recursos quedan expuestos bajo /api, por lo que el endpoint
 * final queda en: /healthcheck/api/health
 */
@ApplicationPath("/api")
public class JaxRsActivator extends Application {
    // No se requiere sobreescribir metodos: el escaneo de anotaciones
    // detecta automaticamente las clases @Path del classpath del WAR.
}
