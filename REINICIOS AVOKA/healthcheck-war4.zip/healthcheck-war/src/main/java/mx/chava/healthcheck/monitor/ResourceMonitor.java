package mx.chava.healthcheck.monitor;

import javax.enterprise.context.ApplicationScoped;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Monitor continuo de CPU y memoria de la JVM.
 *
 * <p>Un {@link ScheduledExecutorService} de un solo hilo daemon toma una
 * muestra cada {@link HealthMonitorConfig#SAMPLE_INTERVAL_MS} y:
 * <ol>
 *   <li>Guarda la muestra en un historial en memoria (ultimos
 *       {@link HealthMonitorConfig#RETENTION_SECONDS} segundos).</li>
 *   <li>Actualiza el tiempo continuo que CPU y memoria llevan por
 *       encima de su umbral ("breach").</li>
 *   <li>Recalcula un {@link HealthSnapshot} inmutable y lo publica en
 *       una {@link AtomicReference}, que es lo unico que el endpoint
 *       REST lee (operacion O(1), sin calculo en el hilo de la
 *       peticion HTTP).</li>
 * </ol>
 *
 * <p>Si CPU o memoria permanecen por encima del umbral configurado
 * durante {@code DEGRADATION_SECONDS} segundos o mas de forma
 * <b>continua</b>, el snapshot se marca como no saludable. En cuanto
 * una muestra vuelve a estar por debajo del umbral, el contador de
 * tiempo se reinicia (no es un promedio, es "tiempo continuo por
 * encima del umbral").
 */
@ApplicationScoped
public class ResourceMonitor {

    private static final Logger LOG = Logger.getLogger(ResourceMonitor.class.getName());

    private final AtomicReference<HealthSnapshot> currentSnapshot =
            new AtomicReference<>(HealthSnapshot.initialUp());

    private final ConcurrentLinkedDeque<ResourceMetricsSample> history = new ConcurrentLinkedDeque<>();

    // Solo los toca el hilo del scheduler (single-threaded), por lo que
    // no requieren sincronizacion adicional entre escrituras.
    private volatile long cpuBreachStartMillis = 0L;
    private volatile long memoryBreachStartMillis = 0L;

    private ScheduledExecutorService scheduler;

    /** Arranca el muestreo periodico. Se invoca al desplegar el WAR. */
    public synchronized void start() {
        if (scheduler != null && !scheduler.isShutdown()) {
            return; // ya esta corriendo, no duplicar el scheduler
        }

        scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "healthcheck-resource-monitor");
            thread.setDaemon(true); // no debe impedir el shutdown de la JVM
            return thread;
        });

        scheduler.scheduleAtFixedRate(
                this::sampleSafely,
                0,
                HealthMonitorConfig.SAMPLE_INTERVAL_MS,
                TimeUnit.MILLISECONDS
        );

        LOG.info(() -> String.format(
                "ResourceMonitor iniciado. intervaloMuestreo=%dms, umbralDegradacion=%ds, "
                        + "retencionHistorial=%ds, umbralCPU=%.1f%%, umbralMemoria=%.1f%%",
                HealthMonitorConfig.SAMPLE_INTERVAL_MS,
                HealthMonitorConfig.DEGRADATION_SECONDS,
                HealthMonitorConfig.RETENTION_SECONDS,
                HealthMonitorConfig.CPU_THRESHOLD_PERCENT,
                HealthMonitorConfig.MEMORY_THRESHOLD_PERCENT));
    }

    /** Detiene el muestreo. Se invoca al des-desplegar/apagar el WAR. */
    public synchronized void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            LOG.info("ResourceMonitor detenido.");
        }
    }

    /** Snapshot actual de salud. Lectura O(1), segura para llamar desde el hilo HTTP. */
    public HealthSnapshot getCurrentSnapshot() {
        return currentSnapshot.get();
    }

    /** Copia del historial de muestras conservadas (para diagnostico). */
    public List<ResourceMetricsSample> getRecentHistory() {
        return List.copyOf(history);
    }

    private void sampleSafely() {
        try {
            sample();
        } catch (Exception e) {
            // Nunca dejar que una excepcion mate el scheduler: si el
            // muestreo se detiene silenciosamente, el health check
            // quedaria "congelado" en el ultimo estado para siempre.
            LOG.log(Level.WARNING, "Error tomando muestra de CPU/memoria", e);
        }
    }

    private void sample() {
        long now = System.currentTimeMillis();
        double cpuPercent = readCpuPercent();
        double memoryPercent = readMemoryPercent();

        history.addLast(new ResourceMetricsSample(now, cpuPercent, memoryPercent));
        pruneHistory(now);

        cpuBreachStartMillis = updateBreach(
                cpuBreachStartMillis, cpuPercent, HealthMonitorConfig.CPU_THRESHOLD_PERCENT, now);
        memoryBreachStartMillis = updateBreach(
                memoryBreachStartMillis, memoryPercent, HealthMonitorConfig.MEMORY_THRESHOLD_PERCENT, now);

        long degradationMillis = HealthMonitorConfig.DEGRADATION_SECONDS * 1000L;

        long cpuBreachDurationMs = cpuBreachStartMillis == 0L ? 0L : now - cpuBreachStartMillis;
        long memoryBreachDurationMs = memoryBreachStartMillis == 0L ? 0L : now - memoryBreachStartMillis;

        boolean cpuDegraded = cpuBreachDurationMs >= degradationMillis;
        boolean memoryDegraded = memoryBreachDurationMs >= degradationMillis;

        HealthSnapshot snapshot = new HealthSnapshot(
                !(cpuDegraded || memoryDegraded),
                cpuPercent,
                memoryPercent,
                cpuDegraded,
                memoryDegraded,
                cpuBreachDurationMs / 1000L,
                memoryBreachDurationMs / 1000L,
                now
        );

        currentSnapshot.set(snapshot);

        if (cpuDegraded || memoryDegraded) {
            LOG.warning(() -> String.format(
                    "Salud degradada: cpu=%.1f%% (breach=%ds) memoria=%.1f%% (breach=%ds)",
                    cpuPercent, cpuBreachDurationMs / 1000L, memoryPercent, memoryBreachDurationMs / 1000L));
        }
    }

    /**
     * Actualiza el instante en que empezo el "breach" continuo.
     * Si la muestra actual sigue por encima del umbral, conserva el
     * inicio previo (o lo fija si es la primera vez). Si vuelve a
     * estar por debajo, reinicia el contador (0 = sin breach activo).
     * Una lectura invalida (-1, MXBean no disponible) NO cuenta como
     * breach ni lo reinicia: simplemente se ignora esa muestra.
     */
    private long updateBreach(long currentBreachStart, double value, double threshold, long now) {
        if (value < 0) {
            return currentBreachStart; // muestra invalida, no afecta el estado
        }
        if (value > threshold) {
            return currentBreachStart == 0L ? now : currentBreachStart;
        }
        return 0L;
    }

    private void pruneHistory(long now) {
        long cutoff = now - (HealthMonitorConfig.RETENTION_SECONDS * 1000L);
        ResourceMetricsSample oldest;
        while ((oldest = history.peekFirst()) != null && oldest.timestampMillis() < cutoff) {
            history.pollFirst();
        }
    }

    /** Uso de CPU del proceso JVM (0-100), o -1 si el MXBean no lo soporta. */
    private double readCpuPercent() {
        java.lang.management.OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        if (osBean instanceof com.sun.management.OperatingSystemMXBean) {
            com.sun.management.OperatingSystemMXBean sunOsBean = (com.sun.management.OperatingSystemMXBean) osBean;
            double load = sunOsBean.getProcessCpuLoad(); // 0.0-1.0, o -1 si no disponible aun
            if (load >= 0) {
                return load * 100.0;
            }
        }
        return -1.0;
    }

    /** Uso de heap (0-100) relativo al maximo configurado (-Xmx), o -1 si no disponible. */
    private double readMemoryPercent() {
        MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        long max = heap.getMax();
        if (max <= 0) {
            max = heap.getCommitted(); // fallback si -Xmx no esta definido
        }
        if (max <= 0) {
            return -1.0;
        }
        return (heap.getUsed() * 100.0) / max;
    }
}
