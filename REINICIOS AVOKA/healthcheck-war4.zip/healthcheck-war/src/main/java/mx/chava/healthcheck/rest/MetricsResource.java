package mx.chava.healthcheck.rest;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import mx.chava.healthcheck.monitor.ResourceMetricsSample;
import mx.chava.healthcheck.monitor.ResourceMonitor;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Endpoint de diagnostico (opcional, no es el health check en si).
 * Expone el historial de muestras conservadas en memoria
 * (por defecto, los ultimos 5 minutos) para poder inspeccionar el
 * comportamiento de CPU/memoria sin depender de herramientas externas.
 *
 * GET /healthcheck/api/health/metrics
 */
@Path("/health/metrics")
public class MetricsResource {

    @Inject
    ResourceMonitor resourceMonitor;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response metrics() {
        List<ResourceMetricsSample> samples = resourceMonitor.getRecentHistory();

        String json = samples.stream()
                .map(s -> String.format(Locale.US,
                        "{\"timestamp\":%d,\"cpuPercent\":%.2f,\"memoryPercent\":%.2f}",
                        s.timestampMillis(), s.cpuPercent(), s.memoryPercent()))
                .collect(Collectors.joining(",", "[", "]"));

        return Response.ok(json).build();
    }
}
