package mx.chava.healthcheck.monitor;

/**
 * Una muestra puntual de consumo de recursos.
 *
 * Clase inmutable clasica (en vez de record) para mantener
 * compatibilidad con Java 11 (record requiere Java 16+).
 */
public final class ResourceMetricsSample {

    private final long timestampMillis;
    private final double cpuPercent;
    private final double memoryPercent;

    /**
     * @param timestampMillis epoch millis en que se tomo la muestra
     * @param cpuPercent      uso de CPU del proceso JVM (0-100), o -1 si no disponible
     * @param memoryPercent   uso de heap (0-100), o -1 si no disponible
     */
    public ResourceMetricsSample(long timestampMillis, double cpuPercent, double memoryPercent) {
        this.timestampMillis = timestampMillis;
        this.cpuPercent = cpuPercent;
        this.memoryPercent = memoryPercent;
    }

    public long timestampMillis() {
        return timestampMillis;
    }

    public double cpuPercent() {
        return cpuPercent;
    }

    public double memoryPercent() {
        return memoryPercent;
    }
}
