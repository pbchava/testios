package mx.chava.healthcheck.rest;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import mx.chava.healthcheck.monitor.HealthSnapshot;
import mx.chava.healthcheck.monitor.ResourceMonitor;

import java.time.Instant;
import java.util.Locale;

/**
 * Health check de liveness + salud de recursos.
 *
 * IMPORTANTE sobre el tiempo de respuesta: este metodo NO calcula nada
 * pesado. Solo lee el ultimo {@link HealthSnapshot} publicado por
 * {@link ResourceMonitor}, que corre en un hilo en background y ya
 * dejo el resultado precalculado. Por eso la respuesta es del orden de
 * milisegundos sin importar cuantas muestras historicas existan.
 *
 * Codigos de respuesta:
 *   - 200 OK                    -> CPU y memoria dentro de rango.
 *   - 500 INTERNAL_SERVER_ERROR -> CPU y/o memoria por encima del
 *                                   umbral configurado durante un
 *                                   periodo continuo >= al umbral de
 *                                   degradacion configurado.
 */
@Path("/health")
public class HealthCheckResource {

    @Inject
    ResourceMonitor resourceMonitor;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response healthCheck() {
        HealthSnapshot snapshot = resourceMonitor.getCurrentSnapshot();

        String json = String.format(Locale.US,
                "{"
                        + "\"status\":\"%s\","
                        + "\"timestamp\":\"%s\","
                        + "\"cpu\":{\"currentPercent\":%.2f,\"degraded\":%b,\"continuousBreachSeconds\":%d},"
                        + "\"memory\":{\"currentPercent\":%.2f,\"degraded\":%b,\"continuousBreachSeconds\":%d}"
                        + "}",
                snapshot.healthy() ? "UP" : "DOWN",
                Instant.now(),
                snapshot.cpuPercent(),
                snapshot.cpuDegraded(),
                snapshot.cpuBreachDurationSeconds(),
                snapshot.memoryPercent(),
                snapshot.memoryDegraded(),
                snapshot.memoryBreachDurationSeconds()
        );

        Response.Status status = snapshot.healthy()
                ? Response.Status.OK
                : Response.Status.INTERNAL_SERVER_ERROR;

        return Response.status(status)
                .entity(json)
                .build();
    }
}
