package mx.chava.healthcheck.monitor;

/**
 * Configuracion del monitor de recursos (CPU/Memoria).
 *
 * Cada valor se puede sobreescribir de dos formas (en este orden de
 * prioridad):
 *   1) System property   -> -Dhealthcheck.xxx=valor   (ej. en standalone.conf)
 *   2) Variable de entorno -> HEALTHCHECK_XXX=valor    (util en contenedores)
 *
 * Si ninguna esta definida, se usa el valor por defecto indicado abajo.
 */
public final class HealthMonitorConfig {

    /** Cada cuanto se toma una muestra de CPU/memoria (ms). Default: 1000 (1s). */
    public static final long SAMPLE_INTERVAL_MS =
            getLong("healthcheck.sample.interval.ms", "HEALTHCHECK_SAMPLE_INTERVAL_MS", 1_000L);

    /**
     * Tiempo continuo (segundos) que CPU o memoria deben permanecer por
     * encima del umbral para considerar el servidor "degradado".
     * Default: 30.
     */
    public static final long DEGRADATION_SECONDS =
            getLong("healthcheck.degradation.seconds", "HEALTHCHECK_DEGRADATION_SECONDS", 30L);

    /**
     * Cuanto tiempo (segundos) de historial de metricas se conserva en
     * memoria para diagnostico. Default: 300 (5 minutos).
     */
    public static final long RETENTION_SECONDS =
            getLong("healthcheck.retention.seconds", "HEALTHCHECK_RETENTION_SECONDS", 300L);

    /** Umbral de CPU (%) a partir del cual se considera "alto". Default: 90.0 */
    public static final double CPU_THRESHOLD_PERCENT =
            getDouble("healthcheck.cpu.threshold", "HEALTHCHECK_CPU_THRESHOLD", 90.0);

    /** Umbral de memoria heap (%) a partir del cual se considera "alto". Default: 90.0 */
    public static final double MEMORY_THRESHOLD_PERCENT =
            getDouble("healthcheck.memory.threshold", "HEALTHCHECK_MEMORY_THRESHOLD", 90.0);

    private HealthMonitorConfig() {
    }

    private static long getLong(String sysProp, String envVar, long defaultValue) {
        String raw = resolve(sysProp, envVar);
        if (raw == null) {
            return defaultValue;
        }
        try {
            return Long.parseLong(raw.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static double getDouble(String sysProp, String envVar, double defaultValue) {
        String raw = resolve(sysProp, envVar);
        if (raw == null) {
            return defaultValue;
        }
        try {
            return Double.parseDouble(raw.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static String resolve(String sysProp, String envVar) {
        String value = System.getProperty(sysProp);
        if (value == null || value.isBlank()) {
            value = System.getenv(envVar);
        }
        return (value == null || value.isBlank()) ? null : value;
    }
}
