# healthcheck-war

Proyecto Maven que genera un WAR (`healthcheck.war`) con un servicio REST
de health check para **WildFly 17-26 (Jakarta EE 8, namespace `javax.*`)**,
que valida:

1. **Liveness**: el servidor responde peticiones HTTP.
2. **Salud de CPU**: el uso de CPU del proceso no lleva **30+ segundos
   continuos** por encima del 90 %.
3. **Salud de memoria (heap)**: el uso de heap no lleva **30+ segundos
   continuos** por encima del 90 %.

Los umbrales y tiempos son **configurables** (ver tabla abajo).

## ¿`javax.*` o `jakarta.*`? Cómo saber cuál necesitas

WildFly cambió el namespace de las APIs de Java/Jakarta EE a partir de la
versión 27 (Jakarta EE 10). Si despliegas un WAR compilado con el
namespace que no es, obtienes un `NoClassDefFoundError` al arrancar
(ej. `Failed to link ... jakarta/servlet/ServletContextListener`, o al
revés con `javax/servlet/...`).

Formas rápidas de confirmar cuál tiene tu servidor:

- **Log de arranque de WildFly**: busca la línea `WildFly Full ##.#.#.Final`
  al iniciar. `## <= 26` → `javax.*` (esta versión del proyecto).
  `## >= 27` → `jakarta.*`.
- **Versión de Weld en un stacktrace** (como el que originó este cambio):
  `org.jboss.weld.core@3.1.x.Final` → CDI 2.0 → Jakarta EE 8 → `javax.*`.
  `org.jboss.weld.core@4.x.Final` o superior → CDI 4.0 → Jakarta EE 10 → `jakarta.*`.
- `$WILDFLY_HOME/bin/standalone.sh --version` (o `.bat` en Windows).

Este proyecto usa `javax.*`. Si tu servidor es WildFly 27+, dime y te
regreso la versión con `jakarta.*` (que ya generamos antes).

## Como funciona (importante para el tiempo de respuesta)

El health check tiene que responder en milisegundos, así que **no mide
CPU/memoria en el momento de la petición**. En vez de eso:

- Desde que el WAR se despliega, un **hilo en background** (`ResourceMonitor`,
  arrancado por un `ServletContextListener`) toma una muestra de CPU y
  memoria cada segundo (configurable) usando los `MXBean` estándar de la
  JVM (`java.lang.management`).
- Cada muestra se guarda en un historial en memoria (por defecto, los
  últimos 5 minutos) y se usa para actualizar cuánto tiempo lleva CPU o
  memoria de forma **continua** por encima del umbral.
- El resultado de cada muestreo se precalcula en un objeto inmutable
  (`HealthSnapshot`) publicado en una referencia atómica.
- El endpoint REST `GET /health` **solo lee esa referencia** — no hace
  ningún cálculo — por lo que responde en microsegundos/milisegundos sin
  importar cuánto historial se esté conservando.

Si CPU o memoria bajan del umbral en cualquier muestra, el contador de
"tiempo continuo por encima del umbral" se reinicia — no es un promedio,
es tiempo *continuo* ininterrumpido.

## Endpoints

### `GET /healthcheck/api/health`

- **200 OK** si CPU y memoria están saludables.
- **500 INTERNAL_SERVER_ERROR** si CPU y/o memoria llevan
  `healthcheck.degradation.seconds` segundos o más por encima de su
  umbral configurado.

Ejemplo de respuesta saludable:

```json
{
  "status": "UP",
  "timestamp": "2026-09-18T23:40:00.000Z",
  "cpu": {"currentPercent": 12.34, "degraded": false, "continuousBreachSeconds": 0},
  "memory": {"currentPercent": 45.67, "degraded": false, "continuousBreachSeconds": 0}
}
```

Ejemplo de respuesta degradada (HTTP 500):

```json
{
  "status": "DOWN",
  "timestamp": "2026-09-18T23:40:00.000Z",
  "cpu": {"currentPercent": 96.10, "degraded": true, "continuousBreachSeconds": 42},
  "memory": {"currentPercent": 55.20, "degraded": false, "continuousBreachSeconds": 0}
}
```

### `GET /healthcheck/api/health/metrics` (diagnóstico, opcional)

Devuelve el historial de muestras conservadas en memoria (por defecto,
últimos 5 minutos), útil para depurar sin herramientas externas:

```json
[
  {"timestamp": 1758153600000, "cpuPercent": 12.3, "memoryPercent": 44.1},
  {"timestamp": 1758153601000, "cpuPercent": 13.0, "memoryPercent": 44.3}
]
```

## Variables de configuración

Cada una se puede definir como **system property** (`-Dxxx=valor`, por
ejemplo en `standalone.conf` / `JAVA_OPTS`) o como **variable de entorno**
(útil en contenedores). La system property tiene prioridad si ambas están
definidas.

| Qué controla | System property | Variable de entorno | Default |
|---|---|---|---|
| Intervalo de muestreo de CPU/memoria | `healthcheck.sample.interval.ms` | `HEALTHCHECK_SAMPLE_INTERVAL_MS` | `1000` (1s) |
| Tiempo continuo de degradación para marcar DOWN | `healthcheck.degradation.seconds` | `HEALTHCHECK_DEGRADATION_SECONDS` | `30` |
| Retención de historial en memoria | `healthcheck.retention.seconds` | `HEALTHCHECK_RETENTION_SECONDS` | `300` (5 min) |
| Umbral de CPU (%) | `healthcheck.cpu.threshold` | `HEALTHCHECK_CPU_THRESHOLD` | `90.0` |
| Umbral de memoria heap (%) | `healthcheck.memory.threshold` | `HEALTHCHECK_MEMORY_THRESHOLD` | `90.0` |

Ejemplo, arrancando WildFly con umbrales distintos:

```bash
JAVA_OPTS="$JAVA_OPTS -Dhealthcheck.cpu.threshold=85 -Dhealthcheck.degradation.seconds=45"
```

O vía variables de entorno (por ejemplo en Docker/Kubernetes):

```bash
export HEALTHCHECK_CPU_THRESHOLD=85
export HEALTHCHECK_DEGRADATION_SECONDS=45
```

## Compilar

```bash
mvn clean package
```

Esto genera `target/healthcheck.war`.

> Si tu WildFly usa el namespace `jakarta.*` (WildFly 27+), este pom
> y este código no van a compilar/desplegar correctamente — pide la
> variante `jakarta.*` en su lugar (ver sección de arriba).
>
> El proyecto compila con **Java 11** (`maven.compiler.release=11`).
> No usa `record`, pattern-matching de `instanceof`, text blocks ni
> switch expressions (todas features de Java 14+), para mantener
> compatibilidad con JDKs 11.

## Desplegar

```bash
cp target/healthcheck.war $WILDFLY_HOME/standalone/deployments/
```

O vía CLI:

```bash
$WILDFLY_HOME/bin/jboss-cli.sh --connect \
  --command="deploy target/healthcheck.war --force"
```

## Probar

```bash
curl -i http://localhost:8080/healthcheck/api/health
curl -i http://localhost:8080/healthcheck/api/health/metrics
```

## Estructura del proyecto

```
healthcheck-war/
├── pom.xml
├── README.md
└── src/main
    ├── java/mx/chava/healthcheck/
    │   ├── rest/
    │   │   ├── JaxRsActivator.java        # activa JAX-RS bajo /api
    │   │   ├── HealthCheckResource.java   # GET /api/health
    │   │   └── MetricsResource.java       # GET /api/health/metrics (diagnostico)
    │   └── monitor/
    │       ├── HealthMonitorConfig.java           # lee la configuracion
    │       ├── ResourceMetricsSample.java         # una muestra de CPU/memoria
    │       ├── HealthSnapshot.java                # estado de salud precalculado
    │       ├── ResourceMonitor.java               # hilo en background + logica de degradacion
    │       └── HealthCheckApplicationLifecycle.java # arranca/detiene el monitor con el WAR
    └── webapp/WEB-INF/
        ├── jboss-web.xml   # fija el context-root en /healthcheck
        └── beans.xml       # habilita CDI (@Inject) para el monitor
```

## Notas sobre las métricas

- **CPU**: se usa `com.sun.management.OperatingSystemMXBean.getProcessCpuLoad()`,
  que reporta el uso de CPU **del proceso de la JVM** (no del sistema
  operativo completo). Es el estándar de facto en OpenJDK/Oracle JDK.
- **Memoria**: se usa el heap (`MemoryMXBean.getHeapMemoryUsage()`),
  comparando uso actual contra el máximo configurado (`-Xmx`). Si no hay
  `-Xmx` definido, se usa el heap comprometido (`committed`) como
  referencia.
- Si algún `MXBean` no puede reportar un valor válido (por ejemplo, en
  los primeros segundos tras el arranque de la JVM), esa muestra se
  ignora para efectos de degradación (no cuenta como breach ni lo
  reinicia), pero sí queda registrada en el historial con valor `-1`.
