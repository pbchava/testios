@echo off

REM Configurar puerto local 8448 para HTTPS mediante HTTP.sys y SSL Certificate
netsh http add sslcert ipport=0.0.0.0:8448 certhash=1751411e67ad8c0504c33bf5dc528fab34309a7b appid={926636e2-068c-49af-91d3-7d1cb9f30692}

REM Crea servicio windows "SymetryIBC_OCR" 
SC CREATE "SymetryIBC_OCR" binpath= "C:\Program Files\SymetryBusOCR\SymetryBusServiceOCR.exe" start=auto
SC START "SymetryIBC_OCR"