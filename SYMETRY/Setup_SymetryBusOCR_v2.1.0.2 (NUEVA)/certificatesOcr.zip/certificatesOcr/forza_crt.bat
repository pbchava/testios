@echo off

REM Forzar la instalacion del certificado en el almacen de autoridades de certificacion raiz de confianza del equipo local
certutil -addstore -f root "%~dp0ocrcrt.crt"