@echo off

REM ruta del certificado PFX al almacen de certificados personal
set CERT_PASSWORD=$yME$t$or4!

REM importar el certificado PFX al almacen de certificados personal
certutil -f -p %CERT_PASSWORD% -importpfx "%~dp0ocrcert.pfx"