@echo off
REM netsh http delete sslcert ipport=0.0.0.0:8448

netsh http delete sslcert ipport=0.0.0.0:8448

REM Eliminar servicio windows "SymetryIBC_OCR"
SC STOP "SymetryIBC_OCR"
SC DELETE "SymetryIBC_OCR"
