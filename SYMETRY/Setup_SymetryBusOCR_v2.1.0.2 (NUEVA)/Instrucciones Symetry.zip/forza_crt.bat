@echo off
REM Forzar la instalación del certificado en el almacén de autoridades de certificación raíz de confianza del equipo local
certutil -addstore -f root "%~dp0certificate_v1.crt"