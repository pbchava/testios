@echo off
REM Agrega puerto 8448 https
netsh http add sslcert ipport=0.0.0.0:8448 certhash=47c5646bee0e8e415d76486d7d5f51f581dc280b appid={926636e2-068c-49af-91d3-7d1cb9f30692} 
REM netsh http add urlacl url=http://+:8448/ user=todos
REM Ingles:
REM netsh http add urlacl url=http://+:8448/ user=Everyone

REM Crea Servicio Windows "SymetryOCR_IBC"
SC CREATE "SymetryIBC_OCR" binpath= "C:\Program Files\SymetryBusOCR\SymetryBusServiceOCR.exe" start=auto
SC START "SymetryIBC_OCR"