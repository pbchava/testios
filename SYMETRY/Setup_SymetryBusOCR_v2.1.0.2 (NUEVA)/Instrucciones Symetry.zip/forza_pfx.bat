@echo off
:: Ruta del certificado PFX y su contraseña
set CERT_PASSWORD=$yME$t$or4!


REM Importar el certificado PFX al almacén de certificados personal
certutil -f -p %CERT_PASSWORD% -importpfx "%~dp0certificate_v1.pfx"

