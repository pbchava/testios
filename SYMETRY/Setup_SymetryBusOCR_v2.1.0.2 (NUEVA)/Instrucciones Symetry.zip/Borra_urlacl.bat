Echo on
REM netsh http delete sslcert ipport=0.0.0.0:8448
netsh http delete urlacl url=http://+:8448/
netsh http delete sslcert ipport=0.0.0.0:8448

REM Borra Servicio Windows "SymetryOCR_IBC"
SC STOP "SymetryIBC_OCR"
SC DELETE "SymetryIBC_OCR"

