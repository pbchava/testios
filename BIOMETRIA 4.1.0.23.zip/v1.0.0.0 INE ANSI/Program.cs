﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace BA.Standard.Util.Test
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Variable que contiene el arreglo de bytes del ansi 378_2004 obtenido con el metodo compartido, se deberá enviar la variable con una sola huella ya segmentada en formato IBSM_ImageData y devolverá el ansi en arreglo de bytes
            var ansiByteArray = GetANSIFromIBSU(IBSM_ImageData);

            //Se envía al metodo AdaterINE, se realiza las modificaciones necesarias para adaptarlo al formato INE
            var ansiIne = Ansi_378_2004.AdapterINE(ansiByteArray);
        }

        // Metodo para obtener el ANSI como arreglo de bytes de la captura realizada con IB, este metodo deben mandarlo a llamar en OnEvent_ResultImageEx que es uno de los metodos de respuesta de IB al capturar
        private static byte[] GetANSIFromIBSU(ref IBSM_ImageData imageData)
        {
            DLL.IBSM_StandardFormatData StdFormatData;
            StdFormatData.Data = new IntPtr(0);
            StdFormatData.DataLength = 0;
            StdFormatData.Format = DLL.IBSM_StandardFormat.ENUM_IBSM_STANDARD_FORMAT_ISO_19794_2_2005;

            var data = new IBSM_ImageData[1];
            data[0] = imageData;

            int nRc;
            nRc = DLL._IBSU_ConvertImageToISOANSI(
                _m_nDevHandle,
                data,
                1,
                DLL.IBSM_ImageFormat.IBSM_IMG_FORMAT_WSQ,
                DLL.IBSM_StandardFormat.ENUM_IBSM_STANDARD_FORMAT_ANSI_INCITS_378_2004,
                ref StdFormatData);

            byte[] buff = new byte[StdFormatData.DataLength];
            if (nRc == DLL.IBSU_STATUS_OK)
            {
                int buffLen = (int)StdFormatData.DataLength;
                Marshal.Copy(StdFormatData.Data, buff, 0, buffLen);
            }
            else Logger.Error($"Error IB: {nRc}");

            return buff;

        }
    }
}
