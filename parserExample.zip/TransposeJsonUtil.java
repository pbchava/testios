package com.banamex.filenet.util;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class TransposeJsonUtil {

	private static final Map<String, String> TRANSPOSE_FIELDS_METADATA = new HashMap<String, String>();
	
	// Private static instance of the class
    private static TransposeJsonUtil single_instance = null;

    // Private constructor restricted to this class itself
    private TransposeJsonUtil() {
    }

    // Public static method to get the instance of the class
    public static TransposeJsonUtil getInstance() {
        if (single_instance == null) {
            single_instance = new TransposeJsonUtil();
        }
        return single_instance;
    }
	
    static {
    	ObjectMapper mapper = new ObjectMapper();
    	try {
            // --- CONFIGURATION ---
            // Key: JSON Pointer to ANY source element
            // Value: Target field name inside fileMetadata
    		TRANSPOSE_FIELDS_METADATA.putAll(mapper.readValue(
			        new File("transpose-config.json"), 
			        new TypeReference<Map<String, String>>() {}
			    ));
		} catch (Exception e) {
			//TODO: Replace with specific exception
			throw new RuntimeException("Failed to load traspose configuration", e);
		} 
    }

    //Based on JSON and transpose-config copy elements into applicationFiles.fileMetadata array
    public JsonNode transpose(JsonNode root) {
        try {
            // Array where elements data requires to be injected
            ArrayNode files = (ArrayNode) root.at("/objRequest/applicationFiles");

            if (files != null && files.isArray()) {
                for (JsonNode file : files) {
                    ObjectNode fileMetadata = (ObjectNode) file.path("fileMetadata");

                    // Process every mapping in the config
                    for (Map.Entry<String, String> entry : TRANSPOSE_FIELDS_METADATA.entrySet()) {
                        String jsonPointer = entry.getKey();
                        String targetFieldName = entry.getValue();

                        // .at() allows navigation to any depth (e.g., /a/b/c)
                        JsonNode sourceNode = root.at(jsonPointer);

                        if (!sourceNode.isMissingNode()) {
                            // Inject the found node into the metadata
                            fileMetadata.set(targetFieldName, sourceNode);
                        }
                    }
                }
            }
        } catch (Exception e) {
        	//TODO: Replace with specific exception
			throw new RuntimeException("Problem on data transpose", e);
        }
        
        return root;
    }
}