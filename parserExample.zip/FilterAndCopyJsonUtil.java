package com.banamex.filenet.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class FilterAndCopyJsonUtil {
    
	// Configure which fields to keep for each documentType
	private static final Map<String, List<String>> FIELDS_BY_DOC_TYPE = new HashMap<>();

	// Private static instance of the class
    private static FilterAndCopyJsonUtil single_instance = null;

    // Private constructor restricted to this class itself
    private FilterAndCopyJsonUtil() {
    }

    // Public static method to get the instance of the class
    public static FilterAndCopyJsonUtil getInstance() {
        if (single_instance == null) {
            single_instance = new FilterAndCopyJsonUtil();
        }
        return single_instance;
    }

    //Configure documentType filters from JSON whitelist
    static {
    	//TODO:Change file path to read from config map
        try (InputStream is = DocumentConfigLoader.class.getResourceAsStream("document-config.json")) {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(is);

            // 1. Get the fields every document must have
            List<String> common = new ArrayList<>();
            root.get("commonFields").forEach(field -> common.add(field.asText()));

            // 2. Iterate through specific document types
            JsonNode docs = root.get("documents");
            Iterator<Map.Entry<String, JsonNode>> fields = docs.fields();

            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                List<String> combinedFields = new ArrayList<>(common);
                
                // Add the unique fields for this specific type
                entry.getValue().forEach(f -> combinedFields.add(f.asText()));
                
                FIELDS_BY_DOC_TYPE.put(entry.getKey(), combinedFields);
            }
        } catch (Exception e) {
        	//TODO: Change RuntimeException to specific process exception
            throw new RuntimeException("Failed to load document configuration", e);
        }
    }

    //Retrieve whitelist on fileMetadata element regarding documentType filter 
    public static List<String> getFields(String docType) {
        return FIELDS_BY_DOC_TYPE.getOrDefault(docType, FIELDS_BY_DOC_TYPE.get("_default"));
    }

    //Perform payload clean regarding documentType whitelist
    public JsonNode cleanJson(JsonNode jsonRoot){
    	//TODO: Not sure if deep copy is required, validate and remove this line if necessary
    	// Make a deep copy of entire JSON
    	ObjectMapper mapper = new ObjectMapper();
    	JsonNode outputRoot = jsonRoot.deepCopy();

        // Traverse applicationFiles and filter each fileMetadata
        JsonNode appFilesNode = outputRoot.path("objRequest").path("applicationFiles");
        if (appFilesNode.isArray()) {
            for (JsonNode fileEntryNode : appFilesNode) {
                if (!(fileEntryNode instanceof ObjectNode)) continue;
                ObjectNode fileEntry = (ObjectNode) fileEntryNode;

                JsonNode fileMetadata = fileEntry.get("fileMetadata");
                if (fileMetadata == null || !fileMetadata.isObject()) continue;

                String documentType = fileMetadata.path("documentType").asText(null);
                List<String> keep = FIELDS_BY_DOC_TYPE.getOrDefault(documentType, FIELDS_BY_DOC_TYPE.get("_default"));

                ObjectNode filtered = mapper.createObjectNode();
                // always keep documentType if present
                if (fileMetadata.has("documentType")) filtered.set("documentType", fileMetadata.get("documentType"));

                // copy allowed fields only
                for (String field : keep) {
                    if (fileMetadata.has(field)) filtered.set(field, fileMetadata.get(field));
                }

                // replace fileMetadata with filtered version
                fileEntry.set("fileMetadata", filtered);
            }
        }
        return outputRoot;
    }
    
    public static void main(String[] args) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(new File("test.json"));
    	
        //TODO: Implement aspect interceptor regarding microservice api call,
        // clean output using FilterAndCopyJsonUtil and parse result as different
        // POJO that implements Interoperability integration
    	System.out.println(
    			mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
    					FilterAndCopyJsonUtil.getInstance().cleanJson(root)
    					)
    			);
    }
}