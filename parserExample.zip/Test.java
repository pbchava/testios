package com.banamex.filenet.util;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Test {
    public static void main(String[] args) throws IOException{
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(new File("test.json"));
        //STAGE1: DATA TRANSPOSE
        JsonNode transpose = TransposeJsonUtil.getInstance().transpose(root);
        //STAGE2: DATA FILTERING
        JsonNode filter = FilterJsonUtil.getInstance().cleanJson(transpose);
       
		//TODO: STAGE3 where filter JsonNode be transformed into Interoperability JSON specification 
    	System.out.println(
    			mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
    					filter
    					)
    			);
    }
}