package bmx.io.scanner.applet;

import bmx.io.devices.DeviceDiagnostics;
import bmx.io.devices.PixelType;
import bmx.io.devices.ScannerDevice;
import bmx.io.devices.ScannerDeviceV2;
import bmx.io.scanner.Scanner;
import bmx.io.utils.BlackWhiteCropper;
import bmx.io.utils.DLLDiagnostics;
import bmx.io.utils.ImageUtil;
import java.applet.Applet;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.logging.Logger;
import netscape.javascript.JSObject;
import org.apache.commons.codec.binary.Base64;

public class ScannerApplet extends Applet implements DeviceDiagnostics, ScannerDevice, ScannerDeviceV2 {
   private static final String[] a;
   private DLLDiagnostics b;
   private Scanner c;
   private BufferedImage d;
   private BufferedImage e;
   private BlackWhiteCropper f;
   private JSObject g;
   private String h;
   private String i;
   private String j;

   public void init() {
      this.g = JSObject.getWindow(this);
      this.h = this.getParameter("onLoad");
      this.i = this.getParameter("onBegin");
      this.j = this.getParameter("onEnd");
      this.b = new DLLDiagnostics(a);
      this.f = new BlackWhiteCropper();
      this.c = new Scanner();
      this.c.init();
      this.g.call(this.h, new String[0]);
   }

   public String[] getDLLSearchPaths() {
      return this.b.getDLLSearchPaths();
   }

   public boolean dependentDLLsFound() {
      return this.b.dependentDLLsFound();
   }

   public String[] getDependentDLLPaths() {
      return this.b.getDependentDLLPaths();
   }

   public boolean isDeviceReady() {
      return this.c.isReady();
   }

   public String getStatus() {
      return Boolean.TRUE.toString();
   }

   public void selectSource() {
      this.c.selectSource();
   }

   public String asignarImagen() {
      this.scan();
      return Boolean.TRUE.toString();
   }

   public String getImgFinal() {
      return this.getFullImage();
   }

   public String getImgFinalMedium() {
      return this.getMediumImage();
   }

   public String getImgFinalThumbnail() {
      return this.getThumbnailImage();
   }

   public String getFullImgFinal() {
      return this.getOriginalImage();
   }

   public String getSizeImg() {
      int[] var1 = this.getFullImageSize();
      return String.format("%d,%d", var1[0], var1[1]);
   }

   public String getImgFullSize() {
      return this.getSizeImg();
   }

   public String getImgSize() {
      return this.getSizeImg();
   }

   public String setTypePixel(String var1) {
      this.setDevicePixelType(Integer.valueOf(var1));
      return Boolean.TRUE.toString();
   }

   public String getPixelTypes() {
      int[] var10000 = this.getDevicePixelTypes();
      String var2 = ",";
      int[] var1 = var10000;
      StringBuilder var3 = new StringBuilder();
      if (var1 != null && var1.length > 0) {
         for(int var6 : var1 = var1) {
            var3.append(var6).append(var2);
         }

         var3.deleteCharAt(var3.length() - var2.length());
      }

      return var3.toString();
   }

   public String isReadyScanner() {
      return Boolean.valueOf(this.isDeviceReady()).toString();
   }

   public String getNextDS() {
      String[] var10000 = this.getDataSources();
      String var2 = "|";
      String[] var1 = var10000;
      StringBuilder var3 = new StringBuilder();
      if (var1 != null && var1.length > 0) {
         for(String var6 : var1 = var1) {
            var3.append(var6).append(var2);
         }

         var3.deleteCharAt(var3.length() - var2.length());
      }

      return var3.toString();
   }

   public String getCurrentDataSource() {
      return this.getDataSource();
   }

   public String setDSName(String var1) {
      this.setDataSource(var1);
      return Boolean.TRUE.toString();
   }

   public void setDeltaRecorte(int var1) {
      this.f.setAutoCropDelta(var1);
   }

   public String isReady() {
      return Boolean.valueOf(this.isDeviceReady()).toString();
   }

   public int[] getDevicePixelTypes() {
      return this.c.getPixelTypes();
   }

   public void setDevicePixelType(int var1) {
      this.c.setPixelType(PixelType.byCode(var1));
   }

   public String[] getDataSources() {
      return this.c.getDataSources();
   }

   public String getDataSource() {
      return this.c.getCurrentDataSource();
   }

   public void setDataSource(String var1) {
      this.c.setDataSource(var1);
   }

   public void scan() {
      this.d = null;
      this.e = null;
      this.g.call(this.i, new String[0]);
      this.c.scan();
      this.g.call(this.j, new String[0]);
   }

   public String getOriginalImage() {
      return Base64.encodeBase64String(ImageUtil.getBytes(this.a()));
   }

   public int[] getOriginalImageSize() {
      Dimension var1 = ImageUtil.getSize(this.a());
      return new int[]{var1.width, var1.height};
   }

   public String getFullImage() {
      return Base64.encodeBase64String(ImageUtil.getBytes(this.b()));
   }

   public int[] getFullImageSize() {
      Dimension var1 = ImageUtil.getSize(this.b());
      return new int[]{var1.width, var1.height};
   }

   public String getMediumImage() {
      BufferedImage var10000 = this.b();
      short var3 = 180;
      short var2 = 218;
      return Base64.encodeBase64String(ImageUtil.getBytes(ImageUtil.resize((Image)var10000, var2, var3)));
   }

   public String getThumbnailImage() {
      BufferedImage var10000 = this.b();
      byte var3 = 90;
      byte var2 = 108;
      return Base64.encodeBase64String(ImageUtil.getBytes(ImageUtil.resize((Image)var10000, var2, var3)));
   }

   private BufferedImage a() {
      if (this.d == null) {
         this.d = this.c.getAcquired();
      }

      return this.d;
   }

   private BufferedImage b() {
      if (this.e == null) {
         this.e = this.f.crop(this.a());
      }

      return this.e;
   }

   static {
      Logger.getLogger(ScannerApplet.class.toString());
      a = new String[]{"jtwain.dll"};
   }
}
