package bmx.io.scanner;

import bmx.io.devices.PixelType;
import bmx.io.utils.ImageUtil;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import net.javajeff.jtwain.JTwain;
import net.javajeff.jtwain.JTwainException;

public class Scanner {
   private PixelType a;
   private String b;
   private BufferedImage c;

   public Scanner() {
      this.a = PixelType.RGB;
   }

   public void init() {
      if (!JTwain.init()) {
         throw new UnsupportedOperationException("JTwain: TWAIN not supported");
      }
   }

   public void selectSource() {
      JTwain._selectSourceAsDefault();
   }

   public void setDataSource(String var1) {
      this.b = var1;
   }

   public String getCurrentDataSource() {
      return this.c() ? this.b : a();
   }

   private static String a() {
      String var0;
      try {
         JTwain.openDSM();
         var0 = JTwain.getDefaultDS();
      } finally {
         try {
            JTwain.closeDSM();
         } catch (JTwainException var4) {
         }

      }

      return var0;
   }

   public boolean isReady() {
      try {
         JTwain.openDSM();
         JTwain.openDS(this.d());
         return true;
      } catch (JTwainException var12) {
      } finally {
         try {
            JTwain.closeDS();
         } catch (JTwainException var11) {
         }

         try {
            JTwain.closeDSM();
         } catch (JTwainException var10) {
         }

      }

      return false;
   }

   public String[] getDataSources() {
      try {
         ArrayList var1 = new ArrayList();
         JTwain.openDSM();
         String var2;
         if (!(var2 = JTwain.getFirstDS()).trim().isEmpty()) {
            var1.add(var2);
         }

         int var3 = 0;

         while(var3++ < 8 && !(var2 = JTwain.getNextDS()).isEmpty()) {
            if (!var2.trim().isEmpty()) {
               var1.add(var2);
            }
         }

         String[] var12 = (String[])var1.toArray(new String[var1.size()]);
         return var12;
      } catch (JTwainException var10) {
      } finally {
         try {
            JTwain.closeDSM();
         } catch (JTwainException var9) {
         }

      }

      return null;
   }

   public int[] getPixelTypes() {
      int[] var1;
      try {
         JTwain.openDSM();
         JTwain.openDS(this.d());
         var1 = JTwain.getPixelTypes();
      } finally {
         try {
            JTwain.closeDS();
         } catch (JTwainException var8) {
         }

         try {
            JTwain.closeDSM();
         } catch (JTwainException var7) {
         }

      }

      return var1;
   }

   public void setPixelType(PixelType var1) {
      this.a = var1;
   }

   public void scan() {
      Image[] var1;
      if ((var1 = this.b()) != null && var1.length != 0) {
         this.c = ImageUtil.getBufferedImage(var1[0]);
      } else {
         throw new IllegalStateException("no images acquired");
      }
   }

   private Image[] b() {
      Image[] var1;
      try {
         JTwain.openDSM();
         JTwain.openDS(this.d());
         JTwain.setPixelType(this.a.code);
         var1 = JTwain.acquire();
      } finally {
         try {
            JTwain.closeDS();
         } catch (JTwainException var8) {
         }

         try {
            JTwain.closeDSM();
         } catch (JTwainException var7) {
         }

      }

      return var1;
   }

   private boolean c() {
      return this.b != null && !this.b.trim().isEmpty();
   }

   private String d() {
      return this.c() ? this.b : JTwain.getDefaultDS();
   }

   public BufferedImage getAcquired() {
      if (this.c == null) {
         throw new IllegalStateException("no images acquired");
      } else {
         return this.c;
      }
   }
}
