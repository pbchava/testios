package bmx.io.devices;

public interface ScannerDeviceV2 {
   String[] getDataSources();

   void setDataSource(String var1);

   String getDataSource();

   int[] getDevicePixelTypes();

   void setDevicePixelType(int var1);

   void setDeltaRecorte(int var1);

   void scan();

   String getOriginalImage();

   int[] getOriginalImageSize();

   String getFullImage();

   int[] getFullImageSize();

   String getMediumImage();

   String getThumbnailImage();
}
