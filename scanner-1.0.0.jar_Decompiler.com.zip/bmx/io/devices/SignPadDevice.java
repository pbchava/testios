package bmx.io.devices;

public interface SignPadDevice {
   String isReady();

   String initTablet();

   String startMinimum();

   String clear();

   int getTabletState();

   int setTabletState(int var1);

   String setPenWidth(String var1);

   String getImagenCodificada();

   String getImgCodificadaMedium();

   String getImgCodificadaThumbnail();
}
