package bmx.io.devices;

public interface ScannerDevice {
   String getStatus();

   void selectSource();

   String asignarImagen();

   String getImgFinal();

   String getImgFinalThumbnail();

   String getImgFinalMedium();

   String getFullImgFinal();

   String getSizeImg();

   String getImgFullSize();

   String getImgSize();

   String setTypePixel(String var1);

   String getPixelTypes();

   String isReadyScanner();

   String getNextDS();

   String getCurrentDataSource();

   String setDSName(String var1);

   void setDeltaRecorte(int var1);

   String isReady();
}
