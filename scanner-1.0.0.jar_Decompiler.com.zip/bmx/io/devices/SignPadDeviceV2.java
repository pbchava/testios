package bmx.io.devices;

public interface SignPadDeviceV2 {
   void startCapture();

   void endCapture();

   String getFullSignature();

   String getMediumSignature();

   String getThumbnailSignature();
}
