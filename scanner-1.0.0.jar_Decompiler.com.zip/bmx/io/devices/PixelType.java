package bmx.io.devices;

public enum PixelType {
   BLACK_WHITE(0),
   GRAY(1),
   RGB(2),
   PALETTE(3);

   public final int code;

   private PixelType(int var3) {
      this.code = var3;
   }

   public static PixelType byCode(int var0) {
      PixelType[] var1;
      int var2 = (var1 = values()).length;

      for(int var3 = 0; var3 < var2; ++var3) {
         PixelType var4;
         if ((var4 = var1[var3]).code == var0) {
            return var4;
         }
      }

      throw new IllegalArgumentException("no such pixel type");
   }
}
