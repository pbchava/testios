package bmx.io.devices;

public interface DeviceDiagnostics {
   String[] getDLLSearchPaths();

   boolean dependentDLLsFound();

   String[] getDependentDLLPaths();

   boolean isDeviceReady();
}
