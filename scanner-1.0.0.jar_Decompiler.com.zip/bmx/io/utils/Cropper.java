package bmx.io.utils;

import java.awt.image.BufferedImage;

public interface Cropper {
   BufferedImage crop(BufferedImage var1);
}
