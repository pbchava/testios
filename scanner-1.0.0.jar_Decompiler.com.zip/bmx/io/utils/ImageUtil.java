package bmx.io.utils;

import java.awt.AlphaComposite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

public class ImageUtil {
   public static byte[] resize(byte[] var0, int var1, int var2) {
      return a(resize((Image)getImage(var0), var1, var2));
   }

   public static BufferedImage resize(BufferedImage var0, int var1) {
      int var10001 = var0.getWidth();
      int var3 = var0.getHeight();
      int var2 = var10001;
      double var6;
      if (var2 > var3) {
         var6 = (double)var1 / (double)var2;
      } else {
         var6 = (double)var1 / (double)var3;
      }

      var1 = (int)(var6 * (double)var2);
      var2 = (int)(var6 * (double)var3);
      Dimension var9 = new Dimension(var1, var2);
      return resize((Image)var0, var9.width, var9.height);
   }

   public static BufferedImage resize(Image var0, int var1, int var2) {
      BufferedImage var3;
      Graphics2D var4;
      (var4 = (var3 = new BufferedImage(var1, var2, 1)).createGraphics()).setComposite(AlphaComposite.Src);
      var4.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      var4.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      var4.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      var4.drawImage(var0, 0, 0, var1, var2, (ImageObserver)null);
      var4.dispose();
      return var3;
   }

   public static byte[] getBytes(Image var0) {
      return a(getBufferedImage(var0));
   }

   public static BufferedImage getBufferedImage(Image var0) {
      BufferedImage var1;
      Graphics2D var2;
      (var2 = (var1 = new BufferedImage(var0.getWidth((ImageObserver)null), var0.getHeight((ImageObserver)null), 1)).createGraphics()).setComposite(AlphaComposite.Src);
      var2.drawImage(var0, 0, 0, (ImageObserver)null);
      var2.dispose();
      return var1;
   }

   private static byte[] a(BufferedImage var0) {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();

      try {
         ImageIO.write(var0, "jpeg", var1);
      } catch (IOException var2) {
         throw new RuntimeException(var2);
      }

      return var1.toByteArray();
   }

   public static BufferedImage getImage(byte[] var0) {
      try {
         return ImageIO.read(new ByteArrayInputStream(var0));
      } catch (IOException var1) {
         throw new RuntimeException(var1);
      }
   }

   public static Dimension getSize(byte[] var0) {
      return getSize(getImage(var0));
   }

   public static Dimension getSize(BufferedImage var0) {
      return new Dimension(var0.getWidth(), var0.getHeight());
   }

   public static byte[] loadBytes(String var0) {
      try {
         InputStream var4;
         byte[] var1 = new byte[(var4 = Thread.currentThread().getContextClassLoader().getResourceAsStream(var0)).available()];

         for(int var2 = 0; var4.available() > 0; var2 += var4.read(var1, var2, var4.available())) {
         }

         var4.close();
         return var1;
      } catch (IOException var3) {
         throw new RuntimeException(var3);
      }
   }

   public static BufferedImage loadImage(String var0) {
      InputStream var2 = Thread.currentThread().getContextClassLoader().getResourceAsStream(var0);

      try {
         return ImageIO.read(var2);
      } catch (IOException var1) {
         throw new RuntimeException(var1);
      }
   }

   public static BufferedImage getBlackWhite(BufferedImage var0) {
      BufferedImage var1;
      Graphics var2;
      (var2 = (var1 = new BufferedImage(var0.getWidth(), var0.getHeight(), 12)).getGraphics()).drawImage(var0, 0, 0, (ImageObserver)null);
      var2.dispose();
      return var1;
   }
}
