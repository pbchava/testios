package bmx.io.utils;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BlackWhiteCropper implements Cropper {
   private static final Logger a = Logger.getLogger(Cropper.class.getName());
   private static final Level b;
   private BlackPixelAreaDetector c = new BlackPixelAreaDetector();
   private int d = 550;

   public BufferedImage crop(BufferedImage var1) {
      int var2 = var1.getWidth();
      int var3 = var1.getHeight();
      a.log(b, String.format("Original {w:%d, h:%d}", var2, var3));
      BufferedImage var4;
      int var5 = (var4 = ImageUtil.resize(var1, this.getAutoCropDelta())).getWidth();
      int var6 = var4.getHeight();
      a.log(b, String.format("Scaled to %d {w:%d, h:%d}", this.getAutoCropDelta(), var5, var6));
      var4 = ImageUtil.getBlackWhite(var4);
      Rectangle var13 = this.c.getCropArea(var4);
      a.log(b, String.format("Crop {x:%d, y:%d, w:%d, h:%d}", var13.x, var13.y, var13.width, var13.height));
      double var10 = (double)var2 / (double)var5;
      var5 = (int)((double)var13.x * var10);
      var6 = (int)((double)var13.y * var10);
      int var7 = (int)((double)var13.width * var10);
      int var14 = (int)((double)var13.height * var10);
      Rectangle var15 = new Rectangle(var5, var6, var7, var14);
      a.log(b, String.format("Rescaled crop {x:%d, y:%d, w:%d, h:%d}", var15.x, var15.y, var15.width, var15.height));
      Rectangle var11 = new Rectangle(0, 0, var2, var3);
      boolean var23 = true;
      var5 = Math.max(var15.x - 70, var11.x);
      var6 = Math.max(var15.y - 70, var11.y);
      var7 = Math.min(var15.x + var15.width + 70, var11.width) - var5;
      int var16 = Math.min(var15.y + var15.height + 70, var11.height) - var6;
      Rectangle var17 = new Rectangle(var5, var6, var7, var16);
      a.log(b, String.format("Padded crop {x:%d, y:%d, w:%d, h:%d}", var17.x, var17.y, var17.width, var17.height));
      return var1.getSubimage(var17.x, var17.y, var17.width, var17.height);
   }

   public int getAutoCropDelta() {
      return this.d;
   }

   public void setAutoCropDelta(int var1) {
      this.d = var1;
   }

   static {
      b = Level.INFO;
   }
}
