package bmx.io.utils;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public interface CropAreaDetector {
   Rectangle getCropArea(BufferedImage var1);
}
