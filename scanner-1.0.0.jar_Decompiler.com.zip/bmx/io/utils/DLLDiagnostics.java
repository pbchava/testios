package bmx.io.utils;

import bmx.io.devices.DeviceDiagnostics;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DLLDiagnostics implements DeviceDiagnostics {
   private final Map a;
   private final String[] b;

   public DLLDiagnostics(String[] var1) {
      this.b = var1;
      this.a = this.a(var1);
   }

   public boolean isDeviceReady() {
      return false;
   }

   public String[] getDLLSearchPaths() {
      return System.getProperty("java.library.path").split(System.getProperty("path.separator"));
   }

   public boolean dependentDLLsFound() {
      String[] var1;
      for(String var4 : var1 = this.b) {
         if (this.a.get(var4) == null) {
            return false;
         }
      }

      return true;
   }

   public String[] getDependentDLLPaths() {
      return (String[])this.a.values().toArray(new String[this.a.size()]);
   }

   private Map a(String[] var1) {
      HashMap var2 = new HashMap();
      List var10 = Arrays.asList(var1);

      String[] var3;
      for(String var6 : var3 = this.getDLLSearchPaths()) {
         for(String var8 : var10) {
            File var9;
            if ((var9 = new File(var6)).exists() && var9.isDirectory() && (var9 = new File(var9, var8)).exists()) {
               var2.put(var8, var9.getAbsolutePath());
            }
         }
      }

      return var2;
   }
}
