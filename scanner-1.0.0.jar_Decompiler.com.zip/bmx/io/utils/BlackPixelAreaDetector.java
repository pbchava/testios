package bmx.io.utils;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;

public class BlackPixelAreaDetector implements CropAreaDetector {
   public Rectangle getCropArea(BufferedImage var1) {
      int var2 = var1.getWidth();
      int var3 = var1.getHeight();
      int[] var10 = a(var1, var2, var3);
      int var4 = 0;
      int var5 = var2 - 1;
      int var6 = 0;
      --var3;
      int var7 = 0;
      int var8 = 0;

      for(int var9 = 0; var7 < var10.length; var9 = var7 / var2) {
         if (var10[var7] != -1) {
            if (var8 < var5) {
               var5 = var8;
            }

            if (var8 > var4) {
               var4 = var8;
            }

            if (var9 < var3) {
               var3 = var9;
            }

            if (var9 > var6) {
               var6 = var9;
            }
         }

         var8 = ++var7 % var2;
      }

      var7 = var4 - var5 + 1;
      var8 = var6 - var3 + 1;
      return new Rectangle(var5, var3, var7, var8);
   }

   private static int[] a(BufferedImage var0, int var1, int var2) {
      try {
         int[] var3 = new int[var1 * var2];
         (new PixelGrabber(var0, 0, 0, var1, var2, var3, 0, var1)).grabPixels();
         return var3;
      } catch (InterruptedException var4) {
         throw new RuntimeException(var4);
      }
   }
}
