package net.javajeff.jtwain;

public class JTwainException extends RuntimeException {
   public JTwainException(String var1) {
      super(var1);
   }
}
