package net.javajeff.jtwain;

import java.awt.Image;

public class JTwain {
   public static final int VMAJOR = 1;
   public static final int VMINOR = 1;
   public static final int RC_SUCCESS = 0;
   public static final int RC_FAILURE = 1;
   public static final int RC_CHECKSTATUS = 2;
   public static final int RC_CANCEL = 3;
   public static final int RC_DSEVENT = 4;
   public static final int RC_NOTDSEVENT = 5;
   public static final int RC_XFERDONE = 6;
   public static final int RC_ENDOFLIST = 7;
   public static final int RC_INFONOTSUPPORTED = 8;
   public static final int RC_DATANOTAVAILABLE = 9;
   public static final int CC_SUCCESS = 0;
   public static final int CC_BUMMER = 1;
   public static final int CC_LOWMEMORY = 2;
   public static final int CC_NODS = 3;
   public static final int CC_MAXCONNECTIONS = 4;
   public static final int CC_OPERATIONERROR = 5;
   public static final int CC_BADCAP = 6;
   public static final int CC_BADPROTOCOL = 9;
   public static final int CC_BADVALUE = 10;
   public static final int CC_SEQERROR = 11;
   public static final int CC_BADDEST = 12;
   public static final int CC_CAPUNSUPPORTED = 13;
   public static final int CC_CAPBADOPERATION = 14;
   public static final int CC_CAPSEQERROR = 15;
   public static final int CC_DENIED = 16;
   public static final int CC_FILEEXISTS = 17;
   public static final int CC_FILENOTFOUND = 18;
   public static final int CC_NOTEMPTY = 19;
   public static final int CC_PAPERJAM = 20;
   public static final int CC_PAPERDOUBLEFEED = 21;
   public static final int CC_FILEWRITEERROR = 22;
   public static final int CC_CHECKDEVICEONLINE = 23;
   public static final int PT_BW = 0;
   public static final int PT_GRAY = 1;
   public static final int PT_RGB = 2;
   public static final int PT_PALETTE = 3;
   public static final int PT_CMY = 4;
   public static final int PT_CMYK = 5;
   public static final int PT_YUV = 6;
   public static final int PT_YUVK = 7;
   public static final int PT_CIEXYZ = 8;

   public static boolean init() {
      try {
         System.loadLibrary("jtwain");
         return true;
      } catch (UnsatisfiedLinkError var0) {
         return false;
      }
   }

   public static native Image[] acquire();

   public static native void acquireToBMP(String var0);

   public static native void closeDS();

   public static native void closeDSM();

   public static native int getCC(int var0);

   public static native String getDefaultDS();

   public static native String getFirstDS();

   public static native String getNextDS();

   public static native int getPixelType();

   public static native int[] getPixelTypes();

   public static native int getRC();

   public static native void openDS(String var0);

   public static native void openDSM();

   public static native void setPixelType(int var0);

   public static native Image _acquire();

   public static native void _selectSourceAsDefault();
}
