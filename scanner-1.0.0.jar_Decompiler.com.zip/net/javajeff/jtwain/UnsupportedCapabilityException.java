package net.javajeff.jtwain;

public class UnsupportedCapabilityException extends RuntimeException {
}
