package org.apache.commons.codec.binary;

import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public abstract class BaseNCodec implements BinaryDecoder, BinaryEncoder {
   public static final int MIME_CHUNK_SIZE = 76;
   public static final int PEM_CHUNK_SIZE = 64;
   protected static final int MASK_8BITS = 255;
   protected static final byte PAD_DEFAULT = 61;
   protected final byte PAD;
   protected final byte pad;
   private final int a;
   private final int b;
   protected final int lineLength;
   private final int c;

   protected BaseNCodec(int var1, int var2, int var3, int var4) {
      this(var1, var2, var3, var4, (byte)61);
   }

   protected BaseNCodec(int var1, int var2, int var3, int var4, byte var5) {
      this.PAD = 61;
      this.a = var1;
      this.b = var2;
      var1 = var3 > 0 && var4 > 0;
      this.lineLength = var1 ? var3 / var2 * var2 : 0;
      this.c = var4;
      this.pad = var5;
   }

   static boolean a(a var0) {
      return var0.c != null;
   }

   static int b(a var0) {
      return var0.c != null ? var0.d - var0.e : 0;
   }

   protected int getDefaultBufferSize() {
      return 8192;
   }

   protected byte[] ensureBufferSize(int var1, a var2) {
      if (var2.c != null && var2.c.length >= var2.d + var1) {
         return var2.c;
      } else {
         if (var2.c == null) {
            var2.c = new byte[this.getDefaultBufferSize()];
            var2.d = 0;
            var2.e = 0;
         } else {
            byte[] var3 = new byte[var2.c.length << 1];
            System.arraycopy(var2.c, 0, var3, 0, var2.c.length);
            var2.c = var3;
         }

         return var2.c;
      }
   }

   final int c(byte[] var1, int var2, int var3, a var4) {
      if (var4.c != null) {
         var3 = Math.min(b(var4), var3);
         System.arraycopy(var4.c, var4.e, var1, var2, var3);
         var4.e += var3;
         if (var4.e >= var4.d) {
            var4.c = null;
         }

         return var3;
      } else {
         return var4.f ? -1 : 0;
      }
   }

   protected static boolean isWhiteSpace(byte var0) {
      switch (var0) {
         case 9:
         case 10:
         case 13:
         case 32:
            return true;
         default:
            return false;
      }
   }

   public Object encode(Object var1) {
      if (!(var1 instanceof byte[])) {
         throw new EncoderException("Parameter supplied to Base-N encode is not a byte[]");
      } else {
         return this.encode((byte[])var1);
      }
   }

   public String encodeToString(byte[] var1) {
      return StringUtils.newStringUtf8(this.encode(var1));
   }

   public String encodeAsString(byte[] var1) {
      return StringUtils.newStringUtf8(this.encode(var1));
   }

   public Object decode(Object var1) {
      if (var1 instanceof byte[]) {
         return this.decode((byte[])var1);
      } else if (var1 instanceof String) {
         return this.decode((String)var1);
      } else {
         throw new DecoderException("Parameter supplied to Base-N decode is not a byte[] or a String");
      }
   }

   public byte[] decode(String var1) {
      return this.decode(StringUtils.getBytesUtf8(var1));
   }

   public byte[] decode(byte[] var1) {
      if (var1 != null && var1.length != 0) {
         a var2 = new a();
         this.a(var1, 0, var1.length, var2);
         this.a(var1, 0, -1, var2);
         var1 = new byte[var2.d];
         this.c(var1, 0, var1.length, var2);
         return var1;
      } else {
         return var1;
      }
   }

   public byte[] encode(byte[] var1) {
      if (var1 != null && var1.length != 0) {
         a var2 = new a();
         this.b(var1, 0, var1.length, var2);
         this.b(var1, 0, -1, var2);
         var1 = new byte[var2.d - var2.e];
         this.c(var1, 0, var1.length, var2);
         return var1;
      } else {
         return var1;
      }
   }

   abstract void b(byte[] var1, int var2, int var3, a var4);

   abstract void a(byte[] var1, int var2, int var3, a var4);

   protected abstract boolean isInAlphabet(byte var1);

   public boolean isInAlphabet(byte[] var1, boolean var2) {
      for(int var3 = 0; var3 < var1.length; ++var3) {
         if (!this.isInAlphabet(var1[var3]) && (!var2 || var1[var3] != this.pad && !isWhiteSpace(var1[var3]))) {
            return false;
         }
      }

      return true;
   }

   public boolean isInAlphabet(String var1) {
      return this.isInAlphabet(StringUtils.getBytesUtf8(var1), true);
   }

   protected boolean containsAlphabetOrPad(byte[] var1) {
      if (var1 == null) {
         return false;
      } else {
         for(byte var4 : var1 = var1) {
            if (this.pad == var4 || this.isInAlphabet(var4)) {
               return true;
            }
         }

         return false;
      }
   }

   public long getEncodedLength(byte[] var1) {
      long var2 = (long)((var1.length + this.a - 1) / this.a) * (long)this.b;
      if (this.lineLength > 0) {
         var2 += (var2 + (long)this.lineLength - 1L) / (long)this.lineLength * (long)this.c;
      }

      return var2;
   }
}
