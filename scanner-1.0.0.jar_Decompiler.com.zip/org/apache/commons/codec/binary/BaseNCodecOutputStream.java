package org.apache.commons.codec.binary;

import java.io.FilterOutputStream;
import java.io.OutputStream;

public class BaseNCodecOutputStream extends FilterOutputStream {
   private final boolean a;
   private final BaseNCodec b;
   private final byte[] c = new byte[1];
   private final a d = new a();

   public BaseNCodecOutputStream(OutputStream var1, BaseNCodec var2, boolean var3) {
      super(var1);
      this.b = var2;
      this.a = var3;
   }

   public void write(int var1) {
      this.c[0] = (byte)var1;
      this.write(this.c, 0, 1);
   }

   public void write(byte[] var1, int var2, int var3) {
      if (var1 == null) {
         throw new NullPointerException();
      } else if (var2 >= 0 && var3 >= 0) {
         if (var2 <= var1.length && var2 + var3 <= var1.length) {
            if (var3 > 0) {
               if (this.a) {
                  this.b.b(var1, var2, var3, this.d);
               } else {
                  this.b.a(var1, var2, var3, this.d);
               }

               this.a(false);
            }

         } else {
            throw new IndexOutOfBoundsException();
         }
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   private void a(boolean var1) {
      int var2;
      if ((var2 = BaseNCodec.b(this.d)) > 0) {
         byte[] var3 = new byte[var2];
         if ((var2 = this.b.c(var3, 0, var2, this.d)) > 0) {
            this.out.write(var3, 0, var2);
         }
      }

      if (var1) {
         this.out.flush();
      }

   }

   public void flush() {
      this.a(true);
   }

   public void close() {
      if (this.a) {
         this.b.b(this.c, 0, -1, this.d);
      } else {
         this.b.a(this.c, 0, -1, this.d);
      }

      this.flush();
      this.out.close();
   }
}
