package org.apache.commons.codec.binary;

import java.nio.charset.Charset;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.Charsets;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public class Hex implements BinaryDecoder, BinaryEncoder {
   public static final Charset DEFAULT_CHARSET;
   public static final String DEFAULT_CHARSET_NAME = "UTF-8";
   private static final char[] a;
   private static final char[] b;
   private final Charset c;

   public static byte[] decodeHex(char[] var0) {
      int var1;
      if (((var1 = var0.length) & 1) != 0) {
         throw new DecoderException("Odd number of characters.");
      } else {
         byte[] var2 = new byte[var1 >> 1];
         int var3 = 0;

         for(int var4 = 0; var4 < var1; ++var3) {
            int var5 = toDigit(var0[var4], var4) << 4;
            ++var4;
            var5 |= toDigit(var0[var4], var4);
            ++var4;
            var2[var3] = (byte)var5;
         }

         return var2;
      }
   }

   public static char[] encodeHex(byte[] var0) {
      return encodeHex(var0, true);
   }

   public static char[] encodeHex(byte[] var0, boolean var1) {
      return encodeHex(var0, var1 ? a : b);
   }

   protected static char[] encodeHex(byte[] var0, char[] var1) {
      int var2;
      char[] var3 = new char[(var2 = var0.length) << 1];
      int var4 = 0;

      for(int var5 = 0; var4 < var2; ++var4) {
         var3[var5++] = var1[(240 & var0[var4]) >>> 4];
         var3[var5++] = var1[15 & var0[var4]];
      }

      return var3;
   }

   public static String encodeHexString(byte[] var0) {
      return new String(encodeHex(var0));
   }

   protected static int toDigit(char var0, int var1) {
      int var2;
      if ((var2 = Character.digit(var0, 16)) == -1) {
         throw new DecoderException("Illegal hexadecimal character " + var0 + " at index " + var1);
      } else {
         return var2;
      }
   }

   public Hex() {
      this.c = DEFAULT_CHARSET;
   }

   public Hex(Charset var1) {
      this.c = var1;
   }

   public Hex(String var1) {
      this(Charset.forName(var1));
   }

   public byte[] decode(byte[] var1) {
      return decodeHex((new String(var1, this.getCharset())).toCharArray());
   }

   public Object decode(Object var1) {
      try {
         return decodeHex(var1 instanceof String ? ((String)var1).toCharArray() : (char[])var1);
      } catch (ClassCastException var2) {
         throw new DecoderException(var2.getMessage(), var2);
      }
   }

   public byte[] encode(byte[] var1) {
      return encodeHexString(var1).getBytes(this.getCharset());
   }

   public Object encode(Object var1) {
      try {
         return encodeHex(var1 instanceof String ? ((String)var1).getBytes(this.getCharset()) : (byte[])var1);
      } catch (ClassCastException var2) {
         throw new EncoderException(var2.getMessage(), var2);
      }
   }

   public Charset getCharset() {
      return this.c;
   }

   public String getCharsetName() {
      return this.c.name();
   }

   public String toString() {
      return super.toString() + "[charsetName=" + this.c + "]";
   }

   static {
      DEFAULT_CHARSET = Charsets.UTF_8;
      a = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
      b = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
   }
}
