package org.apache.commons.codec.binary;

public class CharSequenceUtils {
   static boolean a(CharSequence var0, boolean var1, int var2, CharSequence var3, int var4, int var5) {
      if (var0 instanceof String && var3 instanceof String) {
         return ((String)var0).regionMatches(false, 0, (String)var3, 0, var5);
      } else {
         var1 = 0;
         var2 = 0;
         var4 = var5;

         while(var4-- > 0) {
            var5 = var0.charAt(var1++);
            char var6 = var3.charAt(var2++);
            if (var5 != var6) {
               return false;
            }
         }

         return true;
      }
   }
}
