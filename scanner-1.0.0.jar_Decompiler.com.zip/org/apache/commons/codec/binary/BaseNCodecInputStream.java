package org.apache.commons.codec.binary;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class BaseNCodecInputStream extends FilterInputStream {
   private final BaseNCodec a;
   private final boolean b;
   private final byte[] c = new byte[1];
   private final a d = new a();

   protected BaseNCodecInputStream(InputStream var1, BaseNCodec var2, boolean var3) {
      super(var1);
      this.b = var3;
      this.a = var2;
   }

   public int available() {
      return this.d.f ? 0 : 1;
   }

   public synchronized void mark(int var1) {
   }

   public boolean markSupported() {
      return false;
   }

   public int read() {
      int var1;
      for(var1 = this.read(this.c, 0, 1); var1 == 0; var1 = this.read(this.c, 0, 1)) {
      }

      if (var1 > 0) {
         return (var1 = this.c[0]) < 0 ? var1 + 256 : var1;
      } else {
         return -1;
      }
   }

   public int read(byte[] var1, int var2, int var3) {
      if (var1 == null) {
         throw new NullPointerException();
      } else if (var2 >= 0 && var3 >= 0) {
         if (var2 <= var1.length && var2 + var3 <= var1.length) {
            if (var3 == 0) {
               return 0;
            } else {
               int var4;
               for(var4 = 0; var4 == 0; var4 = this.a.c(var1, var2, var3, this.d)) {
                  if (!BaseNCodec.a(this.d)) {
                     byte[] var6 = new byte[this.b ? 4096 : 8192];
                     int var5 = this.in.read(var6);
                     if (this.b) {
                        this.a.b(var6, 0, var5, this.d);
                     } else {
                        this.a.a(var6, 0, var5, this.d);
                     }
                  }
               }

               return var4;
            }
         } else {
            throw new IndexOutOfBoundsException();
         }
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   public synchronized void reset() {
      throw new IOException("mark/reset not supported");
   }

   public long skip(long var1) {
      if (var1 < 0L) {
         throw new IllegalArgumentException("Negative skip length: " + var1);
      } else {
         byte[] var3 = new byte[512];

         long var4;
         int var7;
         for(var4 = var1; var4 > 0L; var4 -= (long)var7) {
            var7 = (int)Math.min(512L, var4);
            if ((var7 = this.read(var3, 0, var7)) == -1) {
               break;
            }
         }

         return var1 - var4;
      }
   }
}
