package org.apache.commons.codec.binary;

public class Base32 extends BaseNCodec {
   private static final byte[] a = new byte[]{13, 10};
   private static final byte[] b = new byte[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
   private static final byte[] c = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 50, 51, 52, 53, 54, 55};
   private static final byte[] d = new byte[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32};
   private static final byte[] e = new byte[]{48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86};
   private final int f;
   private final byte[] g;
   private final int h;
   private final byte[] i;
   private final byte[] j;

   public Base32() {
      this(false);
   }

   public Base32(byte var1) {
      this(false, var1);
   }

   public Base32(boolean var1) {
      this(0, (byte[])null, var1, (byte)61);
   }

   public Base32(boolean var1, byte var2) {
      this(0, (byte[])null, var1, var2);
   }

   public Base32(int var1) {
      this(var1, a);
   }

   public Base32(int var1, byte[] var2) {
      this(var1, var2, false, (byte)61);
   }

   public Base32(int var1, byte[] var2, boolean var3) {
      this(var1, var2, var3, (byte)61);
   }

   public Base32(int var1, byte[] var2, boolean var3, byte var4) {
      super(5, 8, var1, var2 == null ? 0 : var2.length, var4);
      if (var3) {
         this.i = e;
         this.g = d;
      } else {
         this.i = c;
         this.g = b;
      }

      if (var1 > 0) {
         if (var2 == null) {
            throw new IllegalArgumentException("lineLength " + var1 + " > 0, but lineSeparator is null");
         }

         if (this.containsAlphabetOrPad(var2)) {
            String var5 = StringUtils.newStringUtf8(var2);
            throw new IllegalArgumentException("lineSeparator must not contain Base32 characters: [" + var5 + "]");
         }

         this.h = 8 + var2.length;
         this.j = new byte[var2.length];
         System.arraycopy(var2, 0, this.j, 0, var2.length);
      } else {
         this.h = 8;
         this.j = null;
      }

      this.f = this.h - 1;
      if (this.isInAlphabet(var4) || isWhiteSpace(var4)) {
         throw new IllegalArgumentException("pad must not be in alphabet or whitespace");
      }
   }

   final void a(byte[] var1, int var2, int var3, a var4) {
      if (!var4.f) {
         if (var3 < 0) {
            var4.f = true;
         }

         for(int var5 = 0; var5 < var3; ++var5) {
            byte var6;
            if ((var6 = var1[var2++]) == this.pad) {
               var4.f = true;
               break;
            }

            byte[] var7 = this.ensureBufferSize(this.f, var4);
            if (var6 >= 0 && var6 < this.g.length && (var6 = this.g[var6]) >= 0) {
               var4.h = (var4.h + 1) % 8;
               var4.b = (var4.b << 5) + (long)var6;
               if (var4.h == 0) {
                  var7[var4.d++] = (byte)((int)(var4.b >> 32 & 255L));
                  var7[var4.d++] = (byte)((int)(var4.b >> 24 & 255L));
                  var7[var4.d++] = (byte)((int)(var4.b >> 16 & 255L));
                  var7[var4.d++] = (byte)((int)(var4.b >> 8 & 255L));
                  var7[var4.d++] = (byte)((int)(var4.b & 255L));
               }
            }
         }

         if (var4.f && var4.h >= 2) {
            byte[] var8 = this.ensureBufferSize(this.f, var4);
            switch (var4.h) {
               case 2:
                  var8[var4.d++] = (byte)((int)(var4.b >> 2 & 255L));
                  return;
               case 3:
                  var8[var4.d++] = (byte)((int)(var4.b >> 7 & 255L));
                  return;
               case 4:
                  var4.b >>= 4;
                  var8[var4.d++] = (byte)((int)(var4.b >> 8 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b & 255L));
                  return;
               case 5:
                  var4.b >>= 1;
                  var8[var4.d++] = (byte)((int)(var4.b >> 16 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b >> 8 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b & 255L));
                  return;
               case 6:
                  var4.b >>= 6;
                  var8[var4.d++] = (byte)((int)(var4.b >> 16 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b >> 8 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b & 255L));
                  return;
               case 7:
                  var4.b >>= 3;
                  var8[var4.d++] = (byte)((int)(var4.b >> 24 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b >> 16 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b >> 8 & 255L));
                  var8[var4.d++] = (byte)((int)(var4.b & 255L));
                  return;
               default:
                  throw new IllegalStateException("Impossible modulus " + var4.h);
            }
         }
      }
   }

   final void b(byte[] var1, int var2, int var3, a var4) {
      if (!var4.f) {
         if (var3 < 0) {
            var4.f = true;
            if (var4.h != 0 || this.lineLength != 0) {
               byte[] var8 = this.ensureBufferSize(this.h, var4);
               int var9 = var4.d;
               switch (var4.h) {
                  case 0:
                     break;
                  case 1:
                     var8[var4.d++] = this.i[(int)(var4.b >> 3) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b << 2) & 31];
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     break;
                  case 2:
                     var8[var4.d++] = this.i[(int)(var4.b >> 11) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 6) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 1) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b << 4) & 31];
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     break;
                  case 3:
                     var8[var4.d++] = this.i[(int)(var4.b >> 19) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 14) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 9) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 4) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b << 1) & 31];
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     var8[var4.d++] = this.pad;
                     break;
                  case 4:
                     var8[var4.d++] = this.i[(int)(var4.b >> 27) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 22) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 17) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 12) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 7) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b >> 2) & 31];
                     var8[var4.d++] = this.i[(int)(var4.b << 3) & 31];
                     var8[var4.d++] = this.pad;
                     break;
                  default:
                     throw new IllegalStateException("Impossible modulus " + var4.h);
               }

               var4.g += var4.d - var9;
               if (this.lineLength > 0 && var4.g > 0) {
                  System.arraycopy(this.j, 0, var8, var4.d, this.j.length);
                  var4.d += this.j.length;
               }

            }
         } else {
            for(int var5 = 0; var5 < var3; ++var5) {
               byte[] var6 = this.ensureBufferSize(this.h, var4);
               var4.h = (var4.h + 1) % 5;
               int var7;
               if ((var7 = var1[var2++]) < 0) {
                  var7 += 256;
               }

               var4.b = (var4.b << 8) + (long)var7;
               if (var4.h == 0) {
                  var6[var4.d++] = this.i[(int)(var4.b >> 35) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 30) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 25) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 20) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 15) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 10) & 31];
                  var6[var4.d++] = this.i[(int)(var4.b >> 5) & 31];
                  var6[var4.d++] = this.i[(int)var4.b & 31];
                  var4.g += 8;
                  if (this.lineLength > 0 && this.lineLength <= var4.g) {
                     System.arraycopy(this.j, 0, var6, var4.d, this.j.length);
                     var4.d += this.j.length;
                     var4.g = 0;
                  }
               }
            }

         }
      }
   }

   public boolean isInAlphabet(byte var1) {
      return var1 >= 0 && var1 < this.g.length && this.g[var1] != -1;
   }
}
