package org.apache.commons.codec.binary;

import java.math.BigInteger;

public class Base64 extends BaseNCodec {
   private static byte[] a = new byte[]{13, 10};
   private static final byte[] b = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
   private static final byte[] c = new byte[]{65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
   private static final byte[] d = new byte[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, 62, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51};
   private final byte[] e;
   private final byte[] f;
   private final byte[] g;
   private final int h;
   private final int i;

   public Base64() {
      this(0);
   }

   public Base64(boolean var1) {
      this(76, a, var1);
   }

   public Base64(int var1) {
      this(var1, a);
   }

   public Base64(int var1, byte[] var2) {
      this(var1, var2, false);
   }

   public Base64(int var1, byte[] var2, boolean var3) {
      super(3, 4, var1, var2 == null ? 0 : var2.length);
      this.f = d;
      if (var2 != null) {
         if (this.containsAlphabetOrPad(var2)) {
            String var4 = StringUtils.newStringUtf8(var2);
            throw new IllegalArgumentException("lineSeparator must not contain base64 characters: [" + var4 + "]");
         }

         if (var1 > 0) {
            this.i = 4 + var2.length;
            this.g = new byte[var2.length];
            System.arraycopy(var2, 0, this.g, 0, var2.length);
         } else {
            this.i = 4;
            this.g = null;
         }
      } else {
         this.i = 4;
         this.g = null;
      }

      this.h = this.i - 1;
      this.e = var3 ? c : b;
   }

   public boolean isUrlSafe() {
      return this.e == c;
   }

   final void b(byte[] var1, int var2, int var3, a var4) {
      if (!var4.f) {
         if (var3 < 0) {
            var4.f = true;
            if (var4.h != 0 || this.lineLength != 0) {
               byte[] var8 = this.ensureBufferSize(this.i, var4);
               int var9 = var4.d;
               switch (var4.h) {
                  case 0:
                     break;
                  case 1:
                     var8[var4.d++] = this.e[var4.a >> 2 & 63];
                     var8[var4.d++] = this.e[var4.a << 4 & 63];
                     if (this.e == b) {
                        var8[var4.d++] = this.pad;
                        var8[var4.d++] = this.pad;
                     }
                     break;
                  case 2:
                     var8[var4.d++] = this.e[var4.a >> 10 & 63];
                     var8[var4.d++] = this.e[var4.a >> 4 & 63];
                     var8[var4.d++] = this.e[var4.a << 2 & 63];
                     if (this.e == b) {
                        var8[var4.d++] = this.pad;
                     }
                     break;
                  default:
                     throw new IllegalStateException("Impossible modulus " + var4.h);
               }

               var4.g += var4.d - var9;
               if (this.lineLength > 0 && var4.g > 0) {
                  System.arraycopy(this.g, 0, var8, var4.d, this.g.length);
                  var4.d += this.g.length;
               }

            }
         } else {
            for(int var5 = 0; var5 < var3; ++var5) {
               byte[] var6 = this.ensureBufferSize(this.i, var4);
               var4.h = (var4.h + 1) % 3;
               int var7;
               if ((var7 = var1[var2++]) < 0) {
                  var7 += 256;
               }

               var4.a = (var4.a << 8) + var7;
               if (var4.h == 0) {
                  var6[var4.d++] = this.e[var4.a >> 18 & 63];
                  var6[var4.d++] = this.e[var4.a >> 12 & 63];
                  var6[var4.d++] = this.e[var4.a >> 6 & 63];
                  var6[var4.d++] = this.e[var4.a & 63];
                  var4.g += 4;
                  if (this.lineLength > 0 && this.lineLength <= var4.g) {
                     System.arraycopy(this.g, 0, var6, var4.d, this.g.length);
                     var4.d += this.g.length;
                     var4.g = 0;
                  }
               }
            }

         }
      }
   }

   final void a(byte[] var1, int var2, int var3, a var4) {
      if (!var4.f) {
         if (var3 < 0) {
            var4.f = true;
         }

         for(int var5 = 0; var5 < var3; ++var5) {
            byte[] var6 = this.ensureBufferSize(this.h, var4);
            byte var7;
            if ((var7 = var1[var2++]) == this.pad) {
               var4.f = true;
               break;
            }

            if (var7 >= 0 && var7 < 123 && (var7 = d[var7]) >= 0) {
               var4.h = (var4.h + 1) % 4;
               var4.a = (var4.a << 6) + var7;
               if (var4.h == 0) {
                  var6[var4.d++] = (byte)(var4.a >> 16);
                  var6[var4.d++] = (byte)(var4.a >> 8);
                  var6[var4.d++] = (byte)var4.a;
               }
            }
         }

         if (var4.f && var4.h != 0) {
            byte[] var8 = this.ensureBufferSize(this.h, var4);
            switch (var4.h) {
               case 1:
                  return;
               case 2:
                  var4.a >>= 4;
                  var8[var4.d++] = (byte)var4.a;
                  return;
               case 3:
                  var4.a >>= 2;
                  var8[var4.d++] = (byte)(var4.a >> 8);
                  var8[var4.d++] = (byte)var4.a;
                  return;
               default:
                  throw new IllegalStateException("Impossible modulus " + var4.h);
            }
         }
      }
   }

   public static boolean isArrayByteBase64(byte[] var0) {
      return isBase64(var0);
   }

   public static boolean isBase64(byte var0) {
      return var0 == 61 || var0 >= 0 && var0 < 123 && d[var0] != -1;
   }

   public static boolean isBase64(String var0) {
      return isBase64(StringUtils.getBytesUtf8(var0));
   }

   public static boolean isBase64(byte[] var0) {
      for(int var1 = 0; var1 < var0.length; ++var1) {
         if (!isBase64(var0[var1]) && !isWhiteSpace(var0[var1])) {
            return false;
         }
      }

      return true;
   }

   public static byte[] encodeBase64(byte[] var0) {
      return encodeBase64(var0, false);
   }

   public static String encodeBase64String(byte[] var0) {
      return StringUtils.newStringUtf8(encodeBase64(var0, false));
   }

   public static byte[] encodeBase64URLSafe(byte[] var0) {
      return encodeBase64(var0, false, true);
   }

   public static String encodeBase64URLSafeString(byte[] var0) {
      return StringUtils.newStringUtf8(encodeBase64(var0, false, true));
   }

   public static byte[] encodeBase64Chunked(byte[] var0) {
      return encodeBase64(var0, true);
   }

   public static byte[] encodeBase64(byte[] var0, boolean var1) {
      return encodeBase64(var0, var1, false);
   }

   public static byte[] encodeBase64(byte[] var0, boolean var1, boolean var2) {
      return encodeBase64(var0, var1, var2, Integer.MAX_VALUE);
   }

   public static byte[] encodeBase64(byte[] var0, boolean var1, boolean var2, int var3) {
      if (var0 != null && var0.length != 0) {
         long var5;
         Base64 var7;
         if ((var5 = (var7 = var1 ? new Base64(var2) : new Base64(0, a, var2)).getEncodedLength(var0)) > (long)var3) {
            throw new IllegalArgumentException("Input array too big, the output array would be bigger (" + var5 + ") than the specified maximum size of " + var3);
         } else {
            return var7.encode(var0);
         }
      } else {
         return var0;
      }
   }

   public static byte[] decodeBase64(String var0) {
      return (new Base64()).decode(var0);
   }

   public static byte[] decodeBase64(byte[] var0) {
      return (new Base64()).decode(var0);
   }

   public static BigInteger decodeInteger(byte[] var0) {
      return new BigInteger(1, decodeBase64(var0));
   }

   public static byte[] encodeInteger(BigInteger var0) {
      if (var0 == null) {
         throw new NullPointerException("encodeInteger called with null parameter");
      } else {
         int var1 = var0.bitLength() + 7 >> 3 << 3;
         byte[] var2 = var0.toByteArray();
         byte[] var10000;
         if (var0.bitLength() % 8 != 0 && var0.bitLength() / 8 + 1 == var1 / 8) {
            var10000 = var2;
         } else {
            byte var3 = 0;
            int var4 = var2.length;
            if (var0.bitLength() % 8 == 0) {
               var3 = 1;
               --var4;
            }

            int var5 = var1 / 8 - var4;
            byte[] var6 = new byte[var1 / 8];
            System.arraycopy(var2, var3, var6, var5, var4);
            var10000 = var6;
         }

         return encodeBase64(var10000, false);
      }
   }

   protected boolean isInAlphabet(byte var1) {
      return var1 >= 0 && var1 < this.f.length && this.f[var1] != -1;
   }
}
