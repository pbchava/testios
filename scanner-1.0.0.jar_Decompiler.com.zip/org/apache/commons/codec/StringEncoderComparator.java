package org.apache.commons.codec;

import java.util.Comparator;

public class StringEncoderComparator implements Comparator {
   private final StringEncoder a;

   public StringEncoderComparator() {
      this.a = null;
   }

   public StringEncoderComparator(StringEncoder var1) {
      this.a = var1;
   }

   public int compare(Object var1, Object var2) {
      try {
         Comparable var5 = (Comparable)this.a.encode(var1);
         Comparable var6 = (Comparable)this.a.encode(var2);
         var4 = var5.compareTo(var6);
      } catch (EncoderException var3) {
         var4 = 0;
      }

      return var4;
   }
}
